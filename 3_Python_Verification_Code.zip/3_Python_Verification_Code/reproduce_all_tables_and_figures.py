#!/usr/bin/env python3
"""
Master Reproduction Entry Point for All Manuscript & Supplementary Results
==========================================================================
Executes the complete self-contained simulation and verification suite in
`tubefm_lpc.py`, regenerating:
  - 2_Experimental_Data_CSV_and_JSON/identification_data.npz
  - 2_Experimental_Data_CSV_and_JSON/all_python_results.json
  - All 10 CSV data tables in 2_Experimental_Data_CSV_and_JSON/
  - All manuscript and supplementary figures in 1_Manuscript_Supplementary_and_Response/
"""

from tubefm_lpc import main

if __name__ == '__main__':
    main()
