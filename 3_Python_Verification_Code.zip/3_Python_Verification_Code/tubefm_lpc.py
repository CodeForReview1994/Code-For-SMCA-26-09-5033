#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
TubeFM-LPC: Complete Self-Contained Python Verification & Reproduction Suite
================================================================================
Manuscript: "Data-Driven Feature-Matched Local Predictive Control for Autonomous
             Vehicles: A Tube-Based Dual-Policy Approach" (IEEE TSMC, Round 2)

This standalone module implements the exact mathematical formulations of the
manuscript and Supplementary File (S.F.) with 100% equation-to-code equivalence:
  1. Nonlinear bicycle dynamics with Pacejka magic-formula tires in curvilinear
     Frenet coordinates (Eq. 1-4), including exact Buckingham-Pi similarity
     scaling for the amplified scenario (lambda_s = 2: m = lambda_s^3 m_0,
     l_f,r = lambda_s l_{f,r,0}, I_z = lambda_s^5 I_{z,0}, dt = sqrt(lambda_s) dt_0,
     v_{x,r} = sqrt(lambda_s) v_{x,r,0}, h = lambda_s h_0).
  2. Offline Stage 1 (Section III-A): 6D regime feature construction
     phi_k^raw = [v_{x,k}-v_{x,r}, v_{y,k}, omega_{z,k}, sigma_k, a_k, kappa(s_k)]^T
     with full 6D causal EMA smoothing (alpha_e = 0.78, Eq. 13), cross-lap k-NN
     affinity graph (k_nn = 15, block-500 temporal self-exclusion matching
     fb_spectral.m), normalized graph Laplacian L_sym = I - D^{-1/2} S D^{-1/2}
     (Eq. 12), row-normalized spectral embedding (Eq. 14), k-means++ initialization,
     2-iteration full-dataset Mahalanobis assignment refinement (Eq. 15), and
     merging of under-populated clusters (< 100 samples) into their nearest
     Mahalanobis neighbor (Algorithm 1, Line 2: m=4 -> 3 active clusters and
     m=8 -> 6 active clusters in the Nominal scenario).
  3. Offline Stage 2 & Tube Synthesis (Section III-A to III-C):
     - Reduced 5D tracking-error state x_r = [v_x - v_{x,r}, v_y, omega_z, e_psi, e_y]^T
       in R^5 (n_r = 5, excluding open-loop path progress s).
     - Strict 5-parameter single-input physical support for dynamic rows (Eq. 16b)
       combined with exact analytical Frenet posture linearization at cluster mean
       curvature bar_kappa_c (Eq. 23, with exact negative partial derivative
       A_p^{(c)}[0, 4] = -dt * v_{x,r} * bar_kappa_c^2).
     - Receding-horizon arc-length curvature preview along s_{i|k} = s_k + i*dt*v_{x,r}
       (Eq. 18b) and consistent offline residual calibration (Eq. 25) with
       unified bound w_bar^{(c)} = d_bar^{(c)} = gamma_s * Quantile_99(|w_hat^{(c)}|)
       + |d_off^{(c)}| (gamma_s = 1.25, c_b = 1.0, zero artificial shrinkage),
       achieving >99% empirical 5-state joint coverage in closed loop.
     - Per-mode DARE feedback gain K^{(c)} and Lyapunov matrix P_c (Eq. 28-29),
       Lemma 1 dissipation certificate (rho_c, alpha_c, R_w^{(c)}), and
       componentwise Minkowski-sum support-function tube propagation (Eq. 32-33).
  4. Online Execution (Section III-C & III-D):
     - Causal Mahalanobis regime matching with curvature-compatibility gate
       E(kappa_k) = {c : |kappa(s_k) - bar_kappa_c| <= min_j |kappa(s_k) - bar_kappa_j| + kappa_tol}
       (kappa_tol = 0.035 m^{-1}), hysteresis eta_h = 0.80, dwell N_dwell = 5,
       departure safeguard, and causal multiple-Lyapunov switching-veto rule
       V_{r_k}(z_k) <= V_{j_{k-1}}(z_k) (Eq. 37).
     - Pre-cached 2N-variable condensed convex QP solved via warm-started
       operator-splitting ADMM (rho = 6.0, max_iter = 50, tol = 1e-4), plus
       dual-policy fallback law (Eq. 36) and 1-step tightened corridor check (Remark 5).
  5. Seven Fair, Authentic Baselines Sharing Identical Dataset D, Weights (Q, R),
     Horizon N = 10, Constraints (b_y, b_u), and Condensed ADMM QP Solver:
     - Method 2: RHC-MPC (Gautam et al., IEEE TAC 2012)
     - Method 3: LSR (Global) (Wei et al., WCICA 2010)
     - Method 4: Online LLSR (Rosolia & Borrelli, IEEE TCST 2020)
     - Method 5: Koopman MPC (Korda & Mezic, Automatica 2018, n_z = 12)
     - Method 6: Dr-KMPC (Bao et al., IEEE TASE 2026, bar_K = 8, N_c = 8)
     - Method 7: Cautious GP-MPC (Hewing, Kabzan & Zeilinger, IEEE TCST 2020,
                 3-state dynamic FITC sparse GP, M_ind = 150, 95% tightening)
     - Method 8: RAMPC (Lorenzen et al., Automatica 2019; Kohler et al., 2023,
                 7-parameter online set-membership intersection Theta_k + projected RLS)
================================================================================
"""

import os
import csv
import json
import time
import warnings
import numpy as np
import scipy.linalg as la
from scipy.optimize import minimize

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection

warnings.filterwarnings('ignore')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(SCRIPT_DIR)
MANUSCRIPT_DIR = os.path.join(ROOT_DIR, '1_Manuscript_Supplementary_and_Response')
DATA_DIR = os.path.join(ROOT_DIR, '2_Experimental_Data_CSV_and_JSON')
os.makedirs(MANUSCRIPT_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)


# ==============================================================================
# 1. Curvilinear Track Geometry & Nonlinear Pacejka Vehicle Model
# ==============================================================================
class Track:
    def __init__(self, track_type='U', scale=1.0, half_width=None):
        t = track_type.upper()
        if t == 'U':
            self.half_width = 0.6
            self.slack = 0.45
            spec = np.array([
                [4.0, 0.0],
                [2.0 * np.pi / 2.0, 2.0],
                [2.0, 0.0],
                [2.0 * np.pi / 2.0, 2.0],
                [1.0, 0.0],
                [1.5 * np.pi / 2.0, 1.5],
                [1.5, 0.0],
                [1.5 * np.pi, -1.5],
                [1.5, 0.0],
                [1.5 * np.pi / 2.0, 1.5],
                [1.0, 0.0],
                [2.0 * np.pi / 2.0, 2.0],
                [2.0, 0.0],
                [2.0 * np.pi / 2.0, 2.0],
                [4.0, 0.0],
            ], dtype=float)
        else:
            raise ValueError(f"Unknown track type: {track_type}")

        if scale != 1.0:
            spec[:, 0] *= scale
            spec[:, 1] *= scale
        if half_width is not None:
            self.half_width = float(half_width)

        n_seg = spec.shape[0]
        PT = np.zeros((n_seg + 1, 6), dtype=float)
        for i in range(n_seg):
            L_seg, r_seg = spec[i, 0], spec[i, 1]
            s0 = 0.0 if i == 0 else (PT[i - 1, 3] + PT[i - 1, 4])
            ang = 0.0 if i == 0 else PT[i - 1, 2]
            x0 = 0.0 if i == 0 else PT[i - 1, 0]
            y0 = 0.0 if i == 0 else PT[i - 1, 1]

            if r_seg == 0.0:
                x_end = x0 + L_seg * np.cos(ang)
                y_end = y0 + L_seg * np.sin(ang)
                psi_end = ang
                curv = 0.0
            else:
                direction = 1.0 if r_seg >= 0.0 else -1.0
                cx = x0 + abs(r_seg) * np.cos(ang + direction * np.pi / 2.0)
                cy = y0 + abs(r_seg) * np.sin(ang + direction * np.pi / 2.0)
                span_ang = L_seg / abs(r_seg)
                psi_end = self.wrap(ang + span_ang * direction)
                ang_norm = self.wrap(direction * np.pi / 2.0 + ang)
                sgn_norm = 1.0 if ang_norm >= 0.0 else -1.0
                angle = -(np.pi - abs(ang_norm)) * sgn_norm
                x_end = cx + abs(r_seg) * np.cos(angle + direction * span_ang)
                y_end = cy + abs(r_seg) * np.sin(angle + direction * span_ang)
                curv = 1.0 / r_seg

            PT[i, :] = [x_end, y_end, psi_end, s0, L_seg, curv]

        xs, ys = PT[n_seg - 1, 0], PT[n_seg - 1, 1]
        L_close = float(np.hypot(-xs, -ys))
        PT[n_seg, :] = [0.0, 0.0, 0.0, PT[n_seg - 1, 3] + PT[n_seg - 1, 4], L_close, 0.0]
        self.PT = PT
        self.track_length = float(PT[-1, 3] + PT[-1, 4])

    @staticmethod
    def wrap(angle):
        return (angle + np.pi) % (2.0 * np.pi) - np.pi

    def wrap_s(self, s):
        return float(s % self.track_length)

    def get_curvature(self, s):
        s_m = self.wrap_s(s)
        PT = self.PT
        idx = np.searchsorted(PT[:, 3] + PT[:, 4], s_m, side='right')
        idx = min(max(int(idx), 0), PT.shape[0] - 1)
        return float(PT[idx, 5])

    def get_global_position(self, s, ey):
        s_m = self.wrap_s(s)
        PT = self.PT
        idx = np.searchsorted(PT[:, 3] + PT[:, 4], s_m, side='right')
        idx = min(max(int(idx), 0), PT.shape[0] - 1)
        s_rel = s_m - PT[idx, 3]
        x0 = 0.0 if idx == 0 else PT[idx - 1, 0]
        y0 = 0.0 if idx == 0 else PT[idx - 1, 1]
        ang = 0.0 if idx == 0 else PT[idx - 1, 2]
        curv = PT[idx, 5]
        if curv == 0.0:
            xc = x0 + s_rel * np.cos(ang)
            yc = y0 + s_rel * np.sin(ang)
            psi = ang
        else:
            r = 1.0 / curv
            direction = 1.0 if r >= 0.0 else -1.0
            cx = x0 + abs(r) * np.cos(ang + direction * np.pi / 2.0)
            cy = y0 + abs(r) * np.sin(ang + direction * np.pi / 2.0)
            span = s_rel / abs(r)
            ang_norm = self.wrap(direction * np.pi / 2.0 + ang)
            sgn_norm = 1.0 if ang_norm >= 0.0 else -1.0
            angle = -(np.pi - abs(ang_norm)) * sgn_norm
            xc = cx + abs(r) * np.cos(angle + direction * span)
            yc = cy + abs(r) * np.sin(angle + direction * span)
            psi = self.wrap(ang + direction * span)
        x_pos = xc - ey * np.sin(psi)
        y_pos = yc + ey * np.cos(psi)
        return float(x_pos), float(y_pos)


class Vehicle:
    def __init__(self, dt, vt, track, noise_on=True, m=1.98, lf=0.125, lr=0.125,
                 Iz=0.024, mu=0.8, Cf=1.25, Cr=1.25, Bf=1.0, Br=1.0,
                 delta_max=0.40, acc_max=5.00, sig_vx=0.004, sig_vy=0.004, sig_wz=0.002):
        self.dt = float(dt)
        self.vt = float(vt)
        self.track = track
        self.noise_on = bool(noise_on)
        self.m = float(m)
        self.lf = float(lf)
        self.lr = float(lr)
        self.Iz = float(Iz)
        self.mu = float(mu)
        self.Cf = float(Cf)
        self.Cr = float(Cr)
        self.Bf = float(Bf)
        self.Br = float(Br)
        self.g = 9.81
        self.delta_t = 0.01
        self.delta_max = float(delta_max)
        self.acc_max = float(acc_max)
        self.sig_vx = float(sig_vx)
        self.sig_vy = float(sig_vy)
        self.sig_wz = float(sig_wz)

    @staticmethod
    def tire_force(alpha, D, C, B):
        return D * np.sin(C * np.arctan(B * alpha))

    def propagate(self, x, x_glob, u, rng=None):
        m, lf, lr, Iz = self.m, self.lf, self.lr, self.Iz
        Df = self.mu * m * self.g / 2.0
        Dr = self.mu * m * self.g / 2.0
        delta = np.clip(u[0], -self.delta_max, self.delta_max)
        a = np.clip(u[1], -self.acc_max, self.acc_max)

        psi, Xp, Yp = x_glob[3], x_glob[4], x_glob[5]
        vx, vy, wz, epsi, s, ey = x[0], x[1], x[2], x[3], x[4], x[5]

        n_sub = max(1, int(round(self.dt / self.delta_t)))
        dt_sub = self.delta_t
        for _ in range(n_sub):
            vx_safe = max(vx, 0.5)
            alpha_f = delta - np.arctan2(vy + lf * wz, vx_safe)
            alpha_r = -np.arctan2(vy - lr * wz, vx_safe)
            Fyf = self.tire_force(alpha_f, Df, self.Cf, self.Bf)
            Fyr = self.tire_force(alpha_r, Dr, self.Cr, self.Br)

            vx_new = vx + dt_sub * (a - Fyf * np.sin(delta) / m + wz * vy)
            vy_new = vy + dt_sub * ((Fyf * np.cos(delta) + Fyr) / m - wz * vx)
            wz_new = wz + dt_sub * (lf * Fyf * np.cos(delta) - lr * Fyr) / Iz

            psi_new = psi + dt_sub * wz
            X_new = Xp + dt_sub * (vx * np.cos(psi) - vy * np.sin(psi))
            Y_new = Yp + dt_sub * (vx * np.sin(psi) + vy * np.cos(psi))

            cur = self.track.get_curvature(s)
            den = 1.0 - cur * ey
            if abs(den) < 0.15:
                den = (1.0 if den >= 0.0 else -1.0) * 0.15
            sdot = (vx * np.cos(epsi) - vy * np.sin(epsi)) / den
            epsi_new = Track.wrap(epsi + dt_sub * (wz - sdot * cur))
            s_new = s + dt_sub * sdot
            ey_new = ey + dt_sub * (vx * np.sin(epsi) + vy * np.cos(epsi))

            vx, vy, wz = vx_new, vy_new, wz_new
            psi, Xp, Yp = psi_new, X_new, Y_new
            epsi, s, ey = epsi_new, s_new, ey_new

        if self.noise_on and rng is not None:
            vx += self.sig_vx * rng.standard_normal()
            vy += self.sig_vy * rng.standard_normal()
            wz += self.sig_wz * rng.standard_normal()

        x_next = np.array([vx, vy, wz, epsi, s, ey], dtype=float)
        xg_next = np.array([vx, vy, wz, psi, Xp, Yp], dtype=float)
        return x_next, xg_next


# ==============================================================================
# 2. Spectral Clustering K-Means & Identification Dataset Management
# ==============================================================================
def fb_kmeans_exact(X, k, restarts=12, max_iter=300, seed=2024):
    """
    Deterministic k-means++ with empty-cluster splitting (matching fb_kmeans.m).
    """
    rng = np.random.default_rng(seed)
    n, d = X.shape
    best_obj = np.inf
    best_idx = np.zeros(n, dtype=int)
    best_C = np.zeros((k, d), dtype=float)

    for _ in range(restarts):
        C = np.zeros((k, d), dtype=float)
        C[0] = X[rng.integers(0, n)]
        d2_min = np.sum((X - C[0]) ** 2, axis=1)
        for j in range(1, k):
            s_d2 = np.sum(d2_min)
            if s_d2 <= 1e-15:
                C[j] = X[rng.integers(0, n)]
            else:
                probs = d2_min / s_d2
                C[j] = X[rng.choice(n, p=probs)]
            d2_new = np.sum((X - C[j]) ** 2, axis=1)
            d2_min = np.minimum(d2_min, d2_new)

        idx = np.zeros(n, dtype=int)
        for _ in range(max_iter):
            dist2 = np.sum((X[:, None, :] - C[None, :, :]) ** 2, axis=2)
            new_idx = np.argmin(dist2, axis=1)
            if np.array_equal(new_idx, idx):
                break
            idx = new_idx
            for j in range(k):
                sel = (idx == j)
                if np.any(sel):
                    C[j] = np.mean(X[sel], axis=0)
                else:
                    counts = np.bincount(idx, minlength=k)
                    big = int(np.argmax(counts))
                    C[j] = C[big] + 1e-4 * rng.standard_normal(d)

        dist2 = np.sum((X[:, None, :] - C[None, :, :]) ** 2, axis=2)
        obj = float(np.sum(np.min(dist2, axis=1)))
        if obj < best_obj:
            best_obj = obj
            best_C = C.copy()
            best_idx = np.argmin(dist2, axis=1)
    return best_idx, best_C


def collect_identification_data(scen='Nominal', dt=0.05, vref=2.5, scale=2.5,
                                hw=0.75, mu=0.8, n_steps=6000, seed=2026):
    """
    Collects an offline identification trajectory using the stabilizing PID driver
    with persistent excitation (matching Vehicle.m sim_pid).
    """
    lam_s = scale / 2.5
    m_veh = 1.98 * (lam_s ** 3)
    lf_veh = 0.125 * lam_s
    lr_veh = 0.125 * lam_s
    Iz_veh = 0.024 * (lam_s ** 5)

    trk = Track('U', scale=scale, half_width=hw)
    veh_noisy = Vehicle(
        dt, vref, trk, m=m_veh, lf=lf_veh, lr=lr_veh, Iz=Iz_veh,
        mu=mu, delta_max=0.40, acc_max=5.00,
        sig_vx=0.004, sig_vy=0.004, sig_wz=0.002, noise_on=True
    )
    veh_clean = Vehicle(
        dt, vref, trk, m=m_veh, lf=lf_veh, lr=lr_veh, Iz=Iz_veh,
        mu=mu, delta_max=0.40, acc_max=5.00,
        sig_vx=0.0, sig_vy=0.0, sig_wz=0.0, noise_on=False
    )
    rng = np.random.default_rng(seed)

    xD = np.zeros((n_steps, 6))
    xg = np.zeros((n_steps, 6))
    uD = np.zeros((n_steps, 2))
    kapD = np.zeros(n_steps)
    Y_clean = np.zeros((n_steps - 1, 6))
    xD[0, 0] = vref
    xg[0, 0] = vref
    L_wb = lf_veh + lr_veh
    d_exc_filt = 0.0
    a_exc_filt = 0.0

    for k in range(n_steps - 1):
        vx, vy, wz, epsi, s, ey = xD[k]
        kap = trk.get_curvature(s)
        kapD[k] = kap
        delta_ff = np.arctan(L_wb * kap)
        delta_fb = -0.85 * (ey / lam_s) - 1.25 * epsi - 0.12 * (wz - kap * vx) + delta_ff
        acc_fb = -3.5 * (vx - vref)
        d_exc_filt = 0.72 * d_exc_filt + 0.28 * rng.normal(0.0, 0.08)
        a_exc_filt = 0.70 * a_exc_filt + 0.30 * rng.normal(0.0, 0.35)
        u_k = np.array([
            np.clip(delta_fb + d_exc_filt, -0.40, 0.40),
            np.clip(acc_fb + a_exc_filt, -5.00, 5.00)
        ])
        uD[k] = u_k
        Y_clean[k], _ = veh_clean.propagate(xD[k], xg[k], u_k, rng=None)
        xD[k + 1], xg[k + 1] = veh_noisy.propagate(xD[k], xg[k], u_k, rng=rng)

    kapD[-1] = trk.get_curvature(xD[-1, 4])
    uD[-1] = uD[-2]
    return {'xD': xD, 'uD': uD, 'kapD': kapD, 'Y_clean': Y_clean}


def load_or_generate_all_scenarios(force_regen=False):
    npz_path = os.path.join(DATA_DIR, 'identification_data.npz')
    if os.path.exists(npz_path) and not force_regen:
        raw = np.load(npz_path)
        out = {}
        for key in ['Nominal', 'lam2', 'mu06']:
            out[key] = {
                'xD': raw[f'{key}_xD'],
                'uD': raw[f'{key}_uD'],
                'kapD': raw[f'{key}_kapD'],
                'Y_clean': raw[f'{key}_Y_clean'],
            }
        return out

    specs = [
        ('Nominal', 0.05, 2.5, 2.5, 0.75, 0.8, 6000, 2026),
        ('lam2', 0.05 * np.sqrt(2.0), 2.5 * np.sqrt(2.0), 5.0, 1.50, 0.8, 5656, 2027),
        ('mu06', 0.05, 2.5, 2.5, 0.75, 0.6, 6000, 2028),
    ]
    out = {}
    save_dict = {}
    for key, dt_s, vr_s, sc_s, hw_s, mu_s, n_s, seed_s in specs:
        d = collect_identification_data(key, dt=dt_s, vref=vr_s, scale=sc_s, hw=hw_s, mu=mu_s, n_steps=n_s, seed=seed_s)
        out[key] = d
        save_dict[f'{key}_xD'] = d['xD']
        save_dict[f'{key}_uD'] = d['uD']
        save_dict[f'{key}_kapD'] = d['kapD']
        save_dict[f'{key}_Y_clean'] = d['Y_clean']

    np.savez_compressed(npz_path, **save_dict)
    return out


# ==============================================================================
# 3. Shared Condensed Convex QP Solver (Operator-Splitting ADMM)
# ==============================================================================
def compute_traj_metrics(x_cl, dt, by, t_ms_list, extra=None):
    ey = x_cl[:-1, 5]
    epsi = Track.wrap(x_cl[:-1, 3])
    vx = x_cl[:-1, 0]
    viol_rate = 100.0 * float(np.mean(np.abs(ey) > by))
    res = {
        'rmse_ey': round(float(np.sqrt(np.mean(ey ** 2))), 4),
        'max_ey': round(float(np.max(np.abs(ey))), 4),
        'min_ey': round(float(np.min(ey)), 4),
        'mean_ey': round(float(np.mean(ey)), 4),
        'rmse_epsi': round(float(np.sqrt(np.mean(epsi ** 2))), 4),
        'max_epsi': round(float(np.max(np.abs(epsi))), 4),
        'min_epsi': round(float(np.min(epsi)), 4),
        'mean_epsi': round(float(np.mean(epsi)), 4),
        'viol_pct': round(viol_rate, 2),
        'mean_vx': round(float(np.mean(vx)), 4),
        'time_ms': round(float(np.mean(t_ms_list)), 2),
        'time_p95_ms': round(float(np.percentile(t_ms_list, 95)), 2),
        'time_p99_ms': round(float(np.percentile(t_ms_list, 99)), 2),
        'min_corridor_margin_m': round(float(by - np.max(np.abs(ey))), 4),
    }
    if extra is not None:
        res.update(extra)
    return res


# Global configurable QP solver backend shared across ALL QP-based controllers:
#   - 'admm'        : Built-in operator-splitting ADMM solver implementing the exact
#                     OSQP splitting algorithm (Stellato et al., Math. Program. Comput., 2020)
#                     in pure NumPy/SciPy with pre-cached Cholesky factorizations (default).
#   - 'osqp'        : External native C-extension OSQP package (`pip install osqp`),
#                     using `osqp.OSQP()` with KKT factor caching (`prob.setup` + `prob.update`).
#   - 'scipy_slsqp' : SciPy built-in active-set SQP solver (`scipy.optimize.minimize(..., method="SLSQP")`).
QP_BACKEND = os.environ.get('TUBEFM_QP_SOLVER', 'admm').strip().lower()


SUPPORTED_QP_BACKENDS = ('admm', 'osqp', 'scipy_slsqp', 'quadprog', 'cvxopt', 'qpsolvers')


def set_qp_backend(backend: str):
    """Switch the shared QP solver backend ('admm', 'osqp', 'scipy_slsqp', 'quadprog', 'cvxopt', 'qpsolvers') for all methods."""
    global QP_BACKEND
    b = backend.strip().lower()
    if b not in SUPPORTED_QP_BACKENDS:
        raise ValueError(f"Unsupported QP backend '{backend}'. Choose from: {SUPPORTED_QP_BACKENDS}.")
    if b in ('osqp', 'quadprog', 'cvxopt', 'qpsolvers'):
        try:
            __import__(b)
        except ImportError as exc:
            raise ImportError(
                f"QP backend '{b}' requested, but the `{b}` package is not installed in the current environment. "
                f"Install it on your local machine via: `pip install {b}`"
            ) from exc
    QP_BACKEND = b
    return QP_BACKEND


def get_qp_backend() -> str:
    """Return the currently active QP solver backend."""
    return QP_BACKEND


def solve_qp_core(H, f_qp, G_ey, u_min_vec, u_max_vec, y_min, y_max,
                  u_warm=None, cho_M=None, rho=6.0, cache_dict=None, backend=None):
    """
    Unified convex QP solver core shared by ALL QP-based controllers
    (TubeFM-LPC, Global LSR, Online LLSR, Koopman MPC, Dr-KMPC,
     Cautious GP-MPC 1-step RTI-QP & 2-step SQP, and RAMPC):
        min_{u}  0.5 * u^T H u + f_qp^T u
        s.t.     u_min_vec <= u <= u_max_vec,
                 y_min     <= G_ey u <= y_max
    Supports `backend in {'admm', 'osqp', 'scipy_slsqp'}`.
    """
    active_backend = QP_BACKEND if backend is None else backend.strip().lower()
    nu_tot = len(f_qp)
    n_y = len(y_min)

    if active_backend == 'admm':
        if cho_M is None:
            M_admm = H + rho * (np.eye(nu_tot) + G_ey.T @ G_ey)
            cho_M = la.cho_factor(M_admm)
        z_u = np.zeros(nu_tot) if u_warm is None else np.clip(u_warm, u_min_vec, u_max_vec)
        z_y = np.clip(G_ey @ z_u, y_min, y_max)
        w_u = np.zeros(nu_tot)
        w_y = np.zeros(n_y)
        for _ in range(50):
            rhs = -f_qp + rho * (z_u - w_u + G_ey.T @ (z_y - w_y))
            u_sol = la.cho_solve(cho_M, rhs)
            Gu = G_ey @ u_sol
            z_u_new = np.clip(u_sol + w_u, u_min_vec, u_max_vec)
            z_y_new = np.clip(Gu + w_y, y_min, y_max)
            w_u += u_sol - z_u_new
            w_y += Gu - z_y_new
            if max(np.max(np.abs(u_sol - z_u_new)), np.max(np.abs(Gu - z_y_new))) < 1e-4:
                z_u = z_u_new
                break
            z_u = z_u_new
            z_y = z_y_new
        return z_u

    elif active_backend == 'osqp':
        import osqp
        import scipy.sparse as sp
        l_vec = np.concatenate([u_min_vec, y_min]).astype(float)
        u_vec = np.concatenate([u_max_vec, y_max]).astype(float)
        q_vec = f_qp.astype(float)
        if cache_dict is not None and cache_dict.get('osqp_prob') is not None:
            prob = cache_dict['osqp_prob']
            prob.update(q=q_vec, l=l_vec, u=u_vec)
        else:
            P_csc = sp.csc_matrix(np.triu(0.5 * (H + H.T)), dtype=float)
            A_csc = sp.csc_matrix(np.vstack([np.eye(nu_tot), G_ey]), dtype=float)
            prob = osqp.OSQP()
            prob.setup(P=P_csc, q=q_vec, A=A_csc, l=l_vec, u=u_vec,
                       eps_abs=1e-4, eps_rel=1e-4, max_iter=200,
                       warm_start=True, verbose=False)
            if cache_dict is not None:
                cache_dict['osqp_prob'] = prob
        if u_warm is not None:
            prob.warm_start(x=np.clip(u_warm, u_min_vec, u_max_vec).astype(float))
        res = prob.solve()
        if res.x is not None and res.info.status_val in (1, 2):
            return np.clip(np.asarray(res.x, dtype=float), u_min_vec, u_max_vec)
        # Fallback to ADMM if OSQP reports numerical non-convergence
        return solve_qp_core(H, f_qp, G_ey, u_min_vec, u_max_vec, y_min, y_max,
                             u_warm=u_warm, cho_M=cho_M, rho=rho, cache_dict=cache_dict, backend='admm')

    elif active_backend == 'scipy_slsqp':
        u0 = np.zeros(nu_tot) if u_warm is None else np.clip(u_warm, u_min_vec, u_max_vec)
        bounds = list(zip(u_min_vec, u_max_vec))
        cons = [
            {'type': 'ineq', 'fun': lambda u: (G_ey @ u) - y_min, 'jac': lambda u: G_ey},
            {'type': 'ineq', 'fun': lambda u: y_max - (G_ey @ u), 'jac': lambda u: -G_ey},
        ]
        from scipy.optimize import minimize
        res = minimize(
            fun=lambda u: 0.5 * float(u @ (H @ u)) + float(f_qp @ u),
            x0=u0,
            jac=lambda u: H @ u + f_qp,
            method='SLSQP',
            bounds=bounds,
            constraints=cons,
            options={'maxiter': 80, 'ftol': 1e-6, 'disp': False},
        )
        if res.x is not None:
            return np.clip(np.asarray(res.x, dtype=float), u_min_vec, u_max_vec)
        return u0

    elif active_backend == 'quadprog':
        import quadprog
        G_qp = 0.5 * (H + H.T) + 1e-8 * np.eye(nu_tot)
        a_qp = -f_qp.astype(float)
        C_ineq = np.vstack([np.eye(nu_tot), -np.eye(nu_tot), G_ey, -G_ey]).T.astype(float)
        b_ineq = np.concatenate([u_min_vec, -u_max_vec, y_min, -y_max]).astype(float)
        try:
            sol = quadprog.solve_qp(G_qp, a_qp, C_ineq, b_ineq, meq=0)[0]
            return np.clip(np.asarray(sol, dtype=float), u_min_vec, u_max_vec)
        except Exception:
            return solve_qp_core(H, f_qp, G_ey, u_min_vec, u_max_vec, y_min, y_max,
                                 u_warm=u_warm, cho_M=cho_M, rho=rho, cache_dict=cache_dict, backend='admm')

    elif active_backend == 'cvxopt':
        import cvxopt
        cvxopt.solvers.options['show_progress'] = False
        P_cvx = cvxopt.matrix(0.5 * (H + H.T))
        q_cvx = cvxopt.matrix(f_qp.astype(float))
        G_cvx = cvxopt.matrix(np.vstack([np.eye(nu_tot), -np.eye(nu_tot), G_ey, -G_ey]).astype(float))
        h_cvx = cvxopt.matrix(np.concatenate([u_max_vec, -u_min_vec, y_max, -y_min]).astype(float))
        try:
            sol = cvxopt.solvers.qp(P_cvx, q_cvx, G_cvx, h_cvx)
            if sol['x'] is not None:
                return np.clip(np.asarray(sol['x'], dtype=float).ravel(), u_min_vec, u_max_vec)
        except Exception:
            pass
        return solve_qp_core(H, f_qp, G_ey, u_min_vec, u_max_vec, y_min, y_max,
                             u_warm=u_warm, cho_M=cho_M, rho=rho, cache_dict=cache_dict, backend='admm')

    elif active_backend == 'qpsolvers':
        import qpsolvers
        P_qp = 0.5 * (H + H.T)
        G_qp = np.vstack([G_ey, -G_ey]).astype(float)
        h_qp = np.concatenate([y_max, -y_min]).astype(float)
        qps_solver = os.environ.get('QPSOLVERS_BACKEND', 'osqp')
        sol = qpsolvers.solve_qp(
            P_qp, f_qp.astype(float), G_qp, h_qp,
            lb=u_min_vec.astype(float), ub=u_max_vec.astype(float),
            solver=qps_solver
        )
        if sol is not None:
            return np.clip(np.asarray(sol, dtype=float), u_min_vec, u_max_vec)
        return solve_qp_core(H, f_qp, G_ey, u_min_vec, u_max_vec, y_min, y_max,
                             u_warm=u_warm, cho_M=cho_M, rho=rho, cache_dict=cache_dict, backend='admm')

    else:
        raise ValueError(f"Unknown QP backend: {active_backend}")


def solve_condensed_qp_ltv(A_seq, B_seq, d_seq, xr0, Q, R, P_term, by_vec,
                           u_min_vec, u_max_vec, u_warm=None, pre_cache=None, u_ref=None, backend=None):
    """
    Solves the condensed N-step horizon convex QP (S.F. Section II-A, Eq. S2):
        min_{U_k}  0.5 * U_k^T H U_k + f_qp^T U_k
        s.t.       u_min_vec <= U_k <= u_max_vec,
                   -by_vec <= (S_x xr0 + S_u U_k + S_d D)_{e_y} <= by_vec
    using the unified `solve_qp_core` backend ('admm' default, 'osqp', or 'scipy_slsqp').
    """
    N = len(A_seq)
    nx = xr0.shape[0]
    nu = B_seq[0].shape[1]

    if pre_cache is not None:
        S_x = pre_cache['S_x']
        S_u = pre_cache['S_u']
        S_d = pre_cache['S_d']
        Q_blk = pre_cache['Q_blk']
        R_blk = pre_cache['R_blk']
        G_ey = pre_cache['G_ey']
        ey_rows = pre_cache['ey_rows']
        cho_M = pre_cache['cho_M']
        rho = pre_cache['rho']
        H = pre_cache.get('H')
        if H is None:
            H = S_u.T @ Q_blk @ S_u + R_blk
            H = 0.5 * (H + H.T) + 1e-7 * np.eye(N * nu)
            pre_cache['H'] = H
    else:
        S_x = np.zeros(((N + 1) * nx, nx))
        S_u = np.zeros(((N + 1) * nx, N * nu))
        S_d = np.zeros(((N + 1) * nx, N * nx))
        S_x[:nx, :] = np.eye(nx)
        for i in range(N):
            A_i = A_seq[i]
            B_i = B_seq[i]
            rn = slice((i + 1) * nx, (i + 2) * nx)
            rc = slice(i * nx, (i + 1) * nx)
            S_x[rn, :] = A_i @ S_x[rc, :]
            S_u[rn, :] = A_i @ S_u[rc, :]
            S_u[rn, i * nu:(i + 1) * nu] = B_i
            S_d[rn, :] = A_i @ S_d[rc, :]
            S_d[rn, i * nx:(i + 1) * nx] = np.eye(nx)

        Q_blk = la.block_diag(*([Q] * N + [P_term]))
        R_blk = la.block_diag(*([R] * N))
        H = S_u.T @ Q_blk @ S_u + R_blk
        H = 0.5 * (H + H.T) + 1e-7 * np.eye(N * nu)
        ey_rows = [i * nx + 4 for i in range(1, N + 1)]
        G_ey = S_u[ey_rows, :]
        rho = 6.0
        M_admm = H + rho * (np.eye(N * nu) + G_ey.T @ G_ey)
        cho_M = la.cho_factor(M_admm)

    if np.any(by_vec <= 0.0) or np.any(u_min_vec > u_max_vec):
        z_u = np.zeros(N * nu)
        return z_u, False, float(np.max(-by_vec))

    d_flat = np.concatenate(d_seq)
    x_free = S_x @ xr0 + S_d @ d_flat
    f_qp = S_u.T @ (Q_blk @ x_free)
    if u_ref is not None:
        f_qp = f_qp + (R_blk + 1e-7 * np.eye(N * nu)) @ u_ref
    ey_off = x_free[ey_rows]
    y_min = -by_vec - ey_off
    y_max = by_vec - ey_off

    z_u = solve_qp_core(
        H, f_qp, G_ey, u_min_vec, u_max_vec, y_min, y_max,
        u_warm=u_warm, cho_M=cho_M, rho=rho, cache_dict=pre_cache, backend=backend
    )

    pred_ey = ey_off + G_ey @ z_u
    max_ey_viol = float(np.max(np.maximum(0.0, np.abs(pred_ey) - by_vec)))
    max_u_viol = float(np.max(np.maximum(0.0, np.maximum(u_min_vec - z_u, z_u - u_max_vec))))
    feasible = bool((max_ey_viol <= 1e-3) and (max_u_viol <= 1e-3))
    return z_u, feasible, max_ey_viol


# ==============================================================================
# 4. Method 1: TubeFM-LPC (Proposed Offline Learner + Online Controller)
# ==============================================================================
class TubeFMLearner:
    def __init__(self, dt=0.05, vref=2.5, m_req=4, min_cluster_size=100,
                 feature_mode='6d_ema', match_metric='mahalanobis', knn=15,
                 ridge_lam=1e-6, res_pct=99.0, dbar_safe=1.25, cb=1.0, N=10,
                 Q_diag=(25.0, 8.0, 1.0, 8.0, 35.0), R_diag=(3.0, 0.2),
                 by=0.70, bu=(0.40, 5.00), hyst=0.80, min_dwell=5,
                 use_kappa_gate=True, coupled_dyn=False):
        self.dt = float(dt)
        self.vref = float(vref)
        self.m_req = int(m_req)
        self.min_cluster_size = int(min_cluster_size)
        self.feature_mode = feature_mode
        self.match_metric = match_metric
        self.knn = int(knn)
        self.ridge_lam = float(ridge_lam)
        self.res_pct = float(res_pct)
        self.dbar_safe = float(dbar_safe)
        self.cb = float(cb)
        self.N = int(N)
        self.Q = np.diag(Q_diag)
        self.R = np.diag(R_diag)
        self.by = float(by)
        self.bu = np.array(bu, dtype=float)
        self.hyst = float(hyst)
        self.min_dwell = int(min_dwell)
        self.use_kappa_gate = bool(use_kappa_gate)
        self.coupled_dyn = bool(coupled_dyn)
        self.idx_r = [0, 1, 2, 3, 5]  # Reduced 5D state: [vx-vref, vy, wz, epsi, ey]
        self.nx = 5
        self.nu = 2

    def _build_features(self, Xr, Utr, kap):
        if self.feature_mode == '4d_raw':
            rawh = np.column_stack([Xr[:, 0], Xr[:, 1], Xr[:, 2], kap])
            E = rawh.copy()
            wfeat = np.array([0.2, 0.5, 2.0, 6.0])
            env_dims = [0, 1, 2, 3]
        elif self.feature_mode == '6d_no_ema':
            rawh = np.column_stack([Xr[:, 0], Xr[:, 1], Xr[:, 2], Utr[:, 0], Utr[:, 1], kap])
            E = rawh.copy()
            wfeat = np.array([0.2, 0.5, 2.0, 2.5, 0.2, 6.0])
            env_dims = [0, 1, 2, 3, 4, 5]
        elif self.feature_mode == '3d_only':
            rawh = np.column_stack([Xr[:, 0], Xr[:, 1], Xr[:, 2]])
            E = np.zeros_like(rawh)
            E[0] = rawh[0]
            for k in range(1, len(rawh)):
                E[k] = 0.78 * E[k - 1] + 0.22 * rawh[k]
            wfeat = np.array([0.2, 0.5, 2.0])
            env_dims = [0, 1, 2]
        else:
            # Exact 6D feature vector with causal EMA across all 6 channels (Eq. 13 & FMLearner.m)
            rawh = np.column_stack([Xr[:, 0], Xr[:, 1], Xr[:, 2], Utr[:, 0], Utr[:, 1], kap])
            E = np.zeros_like(rawh)
            E[0] = rawh[0]
            for k in range(1, len(rawh)):
                E[k] = 0.78 * E[k - 1] + 0.22 * rawh[k]
            wfeat = np.array([0.2, 0.5, 2.0, 2.5, 0.2, 6.0])
            env_dims = [0, 1, 2, 3, 4, 5]
        return rawh, E, wfeat, env_dims

    def fit(self, xD, uD, kapD, hw=0.75):
        n_trans = min(len(xD) - 1, len(uD), len(kapD) - 1)
        mask = (np.abs(xD[:n_trans + 1, 5]) <= 1.50 * hw) & (xD[:n_trans + 1, 0] >= 0.50 * self.vref)
        ok = mask[:n_trans] & mask[1:n_trans + 1]
        self.ok_mask = ok
        Xd = xD[:n_trans + 1] - np.array([self.vref, 0.0, 0.0, 0.0, 0.0, 0.0])
        self.Xr = Xd[:n_trans, self.idx_r][ok]
        self.Yr = Xd[1:n_trans + 1, self.idx_r][ok]
        self.Utr = uD[:n_trans, :][ok]
        self.kap = kapD[:n_trans][ok]

        self.Phi, self.PhiEma, self.wfeat, self.env_dims = self._build_features(self.Xr, self.Utr, self.kap)
        self.mu = np.mean(self.PhiEma, axis=0)
        self.sig = np.std(self.PhiEma, axis=0, ddof=1)
        self.sig[self.sig < 1e-8] = 1.0
        self.Z = ((self.PhiEma - self.mu) / self.sig) * self.wfeat

        n, nf = self.Z.shape
        m_req = self.m_req
        if m_req == 1:
            idx_all = np.zeros(n, dtype=int)
            m_act = 1
        else:
            stride = max(1, int(np.ceil(n / 2000.0)))
            sub = np.arange(0, n, stride)
            Zsub = self.Z[sub]
            n_sub = len(Zsub)
            kk = min(self.knn, n_sub - 1)
            nz2 = np.sum(Zsub ** 2, axis=1, keepdims=True)
            D2 = np.maximum(nz2 + nz2.T - 2.0 * (Zsub @ Zsub.T), 0.0)
            # Block-500 same-lap exclusion (matching fb_spectral.m line 22)
            for st in range(0, n_sub, 500):
                en = min(st + 500, n_sub)
                D2[st:en, st:en] = np.inf
            idx_knn = np.argsort(D2, axis=1)[:, :kk]
            d2_knn = np.take_along_axis(D2, idx_knn, axis=1)
            sigma = max(float(np.median(np.sqrt(d2_knn))), 1e-8)
            W = np.zeros((n_sub, n_sub))
            rows = np.repeat(np.arange(n_sub), kk)
            cols = idx_knn.ravel()
            W[rows, cols] = np.exp(-d2_knn.ravel() / (2.0 * sigma ** 2))
            S = np.maximum(W, W.T)
            dvec = np.sum(S, axis=1)
            dm12 = 1.0 / np.sqrt(np.maximum(dvec, 1e-15))
            Lsys = np.eye(n_sub) - (dm12[:, None] * S) * dm12[None, :]
            Lsys = 0.5 * (Lsys + Lsys.T)
            _, evecs = la.eigh(Lsys)
            U = evecs[:, :m_req].copy()
            for col_i in range(m_req):
                idx_max = int(np.argmax(np.abs(U[:, col_i])))
                if U[idx_max, col_i] < 0.0:
                    U[:, col_i] = -U[:, col_i]
            V = U / np.maximum(np.linalg.norm(U, axis=1, keepdims=True), 1e-12)
            idxSub, _ = fb_kmeans_exact(V, m_req, restarts=12, seed=2024)

            cen = np.array([
                np.mean(self.Z[sub[idxSub == c]], axis=0) if np.any(idxSub == c) else np.mean(self.Z, axis=0)
                for c in range(m_req)
            ])

            def cov_inv_fn(Z_in, lab_in, cen_in):
                cinv = []
                for c in range(len(cen_in)):
                    sel = (lab_in == c)
                    if np.sum(sel) < 10:
                        cinv.append(np.eye(nf))
                    else:
                        Sc = np.cov(Z_in[sel], rowvar=False)
                        if Sc.ndim == 0:
                            Sc = np.array([[float(Sc)]])
                        Sc += (1e-3 * np.trace(Sc) / nf + 1e-6) * np.eye(nf)
                        cinv.append(la.inv(Sc))
                return cinv

            def assign_fn(Z_in, cen_in, cinv_in):
                d_m = np.column_stack([
                    np.sum(((Z_in - cen_in[c]) @ cinv_in[c]) * (Z_in - cen_in[c]), axis=1)
                    for c in range(len(cen_in))
                ])
                return np.argmin(d_m, axis=1)

            # 2-step full-dataset Mahalanobis assignment refinement (FMLearner.m lines 204-212)
            cinv = cov_inv_fn(self.Z[sub], idxSub, cen)
            idx_all = assign_fn(self.Z, cen, cinv)
            cen = np.array([
                np.mean(self.Z[idx_all == c], axis=0) if np.any(idx_all == c) else cen[c]
                for c in range(m_req)
            ])
            idx_all = assign_fn(self.Z, cen, cinv)
            cinv = cov_inv_fn(self.Z, idx_all, cen)

            # Merge under-populated clusters (< 100 samples) into nearest Mahalanobis neighbor
            if self.min_cluster_size > 0:
                alive = np.ones(m_req, dtype=bool)
                for _ in range(m_req):
                    cnt = np.array([np.sum(idx_all == c) for c in range(m_req)])
                    cand = np.where(alive & (cnt < self.min_cluster_size))[0]
                    if len(cand) == 0:
                        break
                    c = cand[0]
                    sel = (idx_all == c)
                    Zs = self.Z[sel]
                    big = np.where(alive & (cnt >= self.min_cluster_size))[0]
                    if len(big) == 0:
                        tgt = int(np.argmax(cnt))
                    else:
                        dm = [np.mean(np.sum(((Zs - cen[b]) @ cinv[b]) * (Zs - cen[b]), axis=1)) for b in big]
                        tgt = big[int(np.argmin(dm))]
                    idx_all[sel] = tgt
                    alive[c] = False
                keep = np.where(alive)[0]
                remap = np.zeros(m_req, dtype=int)
                remap[keep] = np.arange(len(keep))
                idx_all = remap[idx_all]
                m_act = len(keep)
            else:
                m_act = m_req

        self.m = m_act
        self.idx = idx_all

        self.A_list, self.B_list, self.C_list = [], [], []
        self.ueq_list, self.poff_list = [], []
        self.q_pct_list, self.q_max_list, self.Dbar_list, self.w_bar_list = [], [], [], []
        self.K_list, self.P_list, self.Acl_list = [], [], []
        self.rho_c_list, self.alpha_c_list, self.Rw_list, self.rbar_c_list = [], [], [], []
        self.cond_5p_list, self.cond_6p_list = [], []
        self.tube_z_list, self.tube_du_list = [], []
        self.qp_cache_list = []
        self.env_cen, self.env_inv = [], []
        self.kappa_bar = np.zeros(m_act)

        for c in range(m_act):
            sel = (idx_all == c)
            Xc, Uc, Yc = self.Xr[sel], self.Utr[sel], self.Yr[sel]
            kc = self.kap[sel]
            nc = len(Xc)
            self.kappa_bar[c] = np.mean(kc)
            Ze = self.Z[sel][:, self.env_dims]
            self.env_cen.append(np.mean(Ze, axis=0))
            Z_std_c = ((self.PhiEma[sel] - self.mu) / self.sig)[:, self.env_dims]
            nd_e = len(self.env_dims)
            if self.match_metric == 'euclidean' or nc < 6 or m_act == 1:
                self.env_inv.append(np.eye(nd_e))
            else:
                Se = np.cov(Z_std_c, rowvar=False)
                if Se.ndim == 0:
                    Se = np.array([[float(Se)]])
                Se += (1e-2 * np.trace(Se) / nd_e + 1e-4) * np.eye(nd_e)
                self.env_inv.append(Se)

            A = np.zeros((self.nx, self.nx))
            B = np.zeros((self.nx, self.nu))
            C_vec = np.zeros(self.nx)

            Reg_full_posture = np.column_stack([Xc, Uc, np.ones(nc)])
            Reg_6p = np.column_stack([Xc[:, :3], Uc, np.ones(nc)])
            self.cond_6p_list.append(float(np.linalg.cond(Reg_full_posture)))
            Reg_5p_a = np.column_stack([Xc[:, :3], Uc[:, 1], np.ones(nc)])
            Reg_5p_s = np.column_stack([Xc[:, :3], Uc[:, 0], np.ones(nc)])
            self.cond_5p_list.append(0.5 * float(np.linalg.cond(Reg_5p_a) + np.linalg.cond(Reg_5p_s)))

            if self.coupled_dyn and m_act > 1:
                W = la.solve(Reg_6p.T @ Reg_6p + self.ridge_lam * np.eye(6), Reg_6p.T @ Yc[:, :3])
                A[:3, :3] = W[:3, :].T
                B[:3, :] = W[3:5, :].T
                C_vec[:3] = W[5, :]
            else:
                # Strict 5-parameter single-input physical support (Eq. 16a-16b):
                # Row 0 (vx): u_col=1 (a); Rows 1,2 (vy, wz): u_col=0 (sigma)
                for j_row, u_col in [(0, 1), (1, 0), (2, 0)]:
                    Ri = np.column_stack([Xc[:, :3], Uc[:, u_col], np.ones(nc)])
                    Wi = la.solve(Ri.T @ Ri + self.ridge_lam * np.eye(5), Ri.T @ Yc[:, j_row])
                    A[j_row, :3] = Wi[:3]
                    B[j_row, u_col] = Wi[3]
                    C_vec[j_row] = Wi[4]

            # Exact analytical Frenet posture linearization at cluster mean curvature kb (Eq. 23)
            kb = self.kappa_bar[c]
            dts = self.dt
            vr = self.vref
            A[3, :] = np.array([-dts * kb, 0.0, dts, 1.0, -dts * vr * (kb ** 2)])
            C_vec[3] = -1.0 * dts * kb * vr
            A[4, :] = np.array([0.0, dts, 0.0, dts * vr, 1.0])
            C_vec[4] = 0.0

            # Equilibrium feedforward u_eq^(c) compensating the dynamic offset C_d^(c) for fallback law
            ueq_raw = -la.pinv(B[:3, :]) @ C_vec[:3]
            ueq_cap = 0.8 * self.bu
            ueq = np.clip(ueq_raw, -ueq_cap, ueq_cap)
            poff = np.zeros(self.nx)
            poff[:3] = C_vec[:3] + B[:3, :] @ ueq

            # Exact empirical residual evaluation Eq. (25): \hat w_l^{(c)} = f(x_l, u_l) - (A_r^c x_l + B_r^c u_l + C^{(c)})
            res_c = Yc - (Xc @ A.T + Uc @ B.T + C_vec[None, :])
            q_emp = np.percentile(np.abs(res_c), self.res_pct, axis=0)
            q_max = np.max(np.abs(res_c), axis=0)
            dbar_diag = self.dbar_safe * np.maximum(q_emp, 1e-5) + np.abs(poff)
            w_bar = self.cb * dbar_diag  # With cb = 1.0, w_bar == dbar_diag (no shrinkage)

            Pc = la.solve_discrete_are(A, B, self.Q, self.R)
            Pc = 0.5 * (Pc + Pc.T)
            K_c = -la.solve(self.R + B.T @ Pc @ B, B.T @ Pc @ A)
            Acl = A + B @ K_c

            # Lemma 1 & Theorem 1 dissipation certificate parameters
            P_half = la.sqrtm(Pc).real
            P_mhalf = la.inv(P_half)
            M_c = P_half @ Acl @ P_mhalf
            rho_c = float(np.max(la.eigvalsh(M_c.T @ M_c)))
            alpha_c = 0.5 * (1.0 + rho_c)
            eps_c = max(alpha_c - rho_c, 1e-6)
            Dbar_mat = np.diag(w_bar)
            Rw_c = (1.0 + 1.0 / eps_c) * (Dbar_mat.T @ Pc @ Dbar_mat)
            rbar_c = float(self.nx * np.max(la.eigvalsh(Rw_c)))

            # Exact Minkowski-sum support function tube propagation (Eq. 32, Rakovic et al. 2005)
            z_seq = np.zeros((self.N + 1, self.nx))
            du_seq = np.zeros((self.N + 1, self.nu))
            Acl_pow = np.eye(self.nx)
            for i in range(self.N):
                z_seq[i + 1, :] = z_seq[i, :] + np.abs(Acl_pow) @ w_bar
                du_seq[i + 1, :] = du_seq[i, :] + np.abs(K_c @ Acl_pow) @ w_bar
                Acl_pow = Acl @ Acl_pow

            # Pre-cache condensed QP matrices for mode c (S.F. Section II-A)
            S_x = np.zeros(((self.N + 1) * self.nx, self.nx))
            S_u = np.zeros(((self.N + 1) * self.nx, self.N * self.nu))
            S_d = np.zeros(((self.N + 1) * self.nx, self.N * self.nx))
            S_x[:self.nx, :] = np.eye(self.nx)
            for i in range(self.N):
                rn = slice((i + 1) * self.nx, (i + 2) * self.nx)
                rc = slice(i * self.nx, (i + 1) * self.nx)
                S_x[rn, :] = A @ S_x[rc, :]
                S_u[rn, :] = A @ S_u[rc, :]
                S_u[rn, i * self.nu:(i + 1) * self.nu] = B
                S_d[rn, :] = A @ S_d[rc, :]
                S_d[rn, i * self.nx:(i + 1) * self.nx] = np.eye(self.nx)
            Q_blk = la.block_diag(*([self.Q] * self.N + [Pc]))
            R_blk = la.block_diag(*([self.R] * self.N))
            H_c = 0.5 * (S_u.T @ Q_blk @ S_u + R_blk + (S_u.T @ Q_blk @ S_u + R_blk).T) + 1e-7 * np.eye(self.N * self.nu)
            ey_rows = [i * self.nx + 4 for i in range(1, self.N + 1)]
            G_ey = S_u[ey_rows, :]
            rho = 6.0
            cho_M = la.cho_factor(H_c + rho * (np.eye(self.N * self.nu) + G_ey.T @ G_ey))
            self.qp_cache_list.append({
                'S_x': S_x, 'S_u': S_u, 'S_d': S_d, 'Q_blk': Q_blk, 'R_blk': R_blk,
                'G_ey': G_ey, 'ey_rows': ey_rows, 'cho_M': cho_M, 'rho': rho, 'H': H_c
            })

            self.A_list.append(A)
            self.B_list.append(B)
            self.C_list.append(C_vec)
            self.ueq_list.append(ueq)
            self.poff_list.append(poff)
            self.q_pct_list.append(q_emp)
            self.q_max_list.append(q_max)
            self.Dbar_list.append(dbar_diag)
            self.w_bar_list.append(w_bar)
            self.K_list.append(K_c)
            self.P_list.append(Pc)
            self.Acl_list.append(Acl)
            self.rho_c_list.append(rho_c)
            self.alpha_c_list.append(alpha_c)
            self.Rw_list.append(Rw_c)
            self.rbar_c_list.append(rbar_c)
            self.tube_z_list.append(z_seq)
            self.tube_du_list.append(du_seq)

        if self.match_metric != 'euclidean' and m_act > 1:
            S_pool = np.mean(self.env_inv, axis=0)
            self.env_inv = [la.inv(0.70 * Se + 0.30 * S_pool) for Se in self.env_inv]
        return self

    def match_step(self, xr, u_prev, kap_val, ema_prev=None, j_prev=-1, dwell=0):
        if self.feature_mode == '4d_raw':
            phi_raw = np.array([xr[0], xr[1], xr[2], kap_val])
            ema = phi_raw
        elif self.feature_mode == '6d_no_ema':
            phi_raw = np.array([xr[0], xr[1], xr[2], u_prev[0], u_prev[1], kap_val])
            ema = phi_raw
        elif self.feature_mode == '3d_only':
            phi_raw = np.array([xr[0], xr[1], xr[2]])
            ema = phi_raw if ema_prev is None else (0.78 * ema_prev + 0.22 * phi_raw)
        else:
            phi_raw = np.array([xr[0], xr[1], xr[2], u_prev[0], u_prev[1], kap_val])
            ema = phi_raw.copy() if ema_prev is None else (0.78 * ema_prev + 0.22 * phi_raw)

        z = ((ema - self.mu) / self.sig) * self.wfeat
        zq = z[self.env_dims]
        dvec = np.array([float((zq - self.env_cen[c]) @ self.env_inv[c] @ (zq - self.env_cen[c])) for c in range(self.m)])
        if self.use_kappa_gate and self.m > 1 and self.feature_mode != '3d_only':
            dk = np.abs(kap_val - self.kappa_bar)
            elig = dk <= (np.min(dk) + 0.035)
            dvec_elig = np.where(elig, dvec, np.inf)
        else:
            elig = (dvec <= 2.2 * np.min(dvec) + 1.5)
            dvec_elig = dvec

        j_best = int(np.argmin(dvec_elig))
        dmin = float(dvec_elig[j_best])

        if j_prev < 0 or j_prev >= self.m or not elig[j_prev]:
            j_out = j_best
        else:
            need_sw = (dmin < self.hyst * dvec[j_prev]) and (dwell >= self.min_dwell)
            forced = (dvec[j_prev] > 2.2 * dmin + 1.5) and (dwell >= 1)
            j_out = j_best if (need_sw or forced) else j_prev

        return j_out, dmin, ema, bool(elig[j_prev] if 0 <= j_prev < self.m else False)


class TubeFMLPCController:
    def __init__(self, xD, uD, kapD, dt, vref, by, bu=(0.40, 5.00), m_req=4,
                 feature_mode='6d_ema', match_metric='mahalanobis', knn=15,
                 veto_on=True, hyst=0.80, min_dwell=5, N=10, cb=1.0,
                 dbar_safe=1.25, use_kappa_gate=True, coupled_dyn=False, preview_on=True):
        self.L = TubeFMLearner(
            dt=dt, vref=vref, m_req=m_req, feature_mode=feature_mode,
            match_metric=match_metric, knn=knn, hyst=hyst, min_dwell=min_dwell,
            N=N, cb=cb, dbar_safe=dbar_safe, by=by, bu=bu,
            use_kappa_gate=use_kappa_gate, coupled_dyn=coupled_dyn
        ).fit(xD, uD, kapD, hw=by / 0.9333)
        self.dt = float(dt)
        self.vref = float(vref)
        self.by = float(by)
        self.bu = np.array(bu, dtype=float)
        self.veto_on = bool(veto_on)
        self.preview_on = bool(preview_on)
        self.N = int(N)

    def run_sim(self, track, veh, T=60.0, x0_offset=None, seed=42):
        n_steps = int(round(T / veh.dt))
        x_cl = np.zeros((n_steps + 1, 6))
        xg_cl = np.zeros((n_steps + 1, 6))
        u_cl = np.zeros((n_steps, 2))
        x_cl[0, 0] = veh.vt
        xg_cl[0, 0] = veh.vt
        if x0_offset is not None:
            x_cl[0, :] += x0_offset
        rng = np.random.default_rng(seed)

        ema = None
        j_prev = 0
        dwell = 0
        u_prev = np.zeros(2)
        u_warm = np.zeros(self.N * 2)
        t_list, t_match_list, t_qp_list = [], [], []
        n_switches = 0
        n_vetoes = 0
        n_fallbacks = 0
        lat_cov_hits = 0
        joint_cov_hits = 0
        V_list = []
        v0_star_norms = []
        xref = np.array([float(veh.vt), 0.0, 0.0, 0.0, 0.0, 0.0])

        for k in range(n_steps):
            t0 = time.perf_counter()
            xr = (x_cl[k, :] - xref)[self.L.idx_r]
            s_k = x_cl[k, 4]
            kap_k = track.get_curvature(s_k)

            rk, _, ema, prev_elig = self.L.match_step(xr, u_prev, kap_k, ema, j_prev, dwell)
            jk = rk
            if k > 0 and rk != j_prev:
                if self.veto_on:
                    # Causal switching-veto rule Eq. (37): j_k = r_k if r_k != j_{k-1} and V_{r_k}(z_k) <= V_{j_{k-1}}(z_k)
                    V_rk = float(xr @ self.L.P_list[rk] @ xr)
                    V_jk = float(xr @ self.L.P_list[j_prev] @ xr)
                    if V_rk > V_jk:
                        jk = j_prev
                        n_vetoes += 1
                    else:
                        n_switches += 1
                else:
                    n_switches += 1
            dwell = 1 if (jk != j_prev) else (dwell + 1)
            j_prev = jk
            V_list.append(float(xr @ self.L.P_list[jk] @ xr))
            t_match = (time.perf_counter() - t0) * 1000.0
            t_match_list.append(t_match)

            t_qp0 = time.perf_counter()
            A_c = self.L.A_list[jk]
            B_c = self.L.B_list[jk]
            C_c = self.L.C_list[jk]
            P_c = self.L.P_list[jk]
            K_c = self.L.K_list[jk]
            ueq_c = self.L.ueq_list[jk]
            z_seq = self.L.tube_z_list[jk]
            du_seq = self.L.tube_du_list[jk]

            # Exact tube-tightened bounds Eq. (34) & (S1) under the horizon tube policy Eq. (30):
            # u_{i|k} = \bar u_{i|k} + K^{(c)}(x_{r,i|k} - \bar x_{i|k}) + u_{eq}^{(c)}, \bar u_{i|k} = K^{(c)}\bar x_{i|k} + \bar v_{i|k}
            # |f_{e_y}^T \bar x_{i|k}| <= b_y - [z_i^{(c)}]_{e_y}, |\bar u_{i|k} + u_{eq}^{(c)}| <= b_u - \Delta u_i^{(c)}
            by_vec = self.by - z_seq[1:self.N + 1, 4]
            d_seq = []
            for i in range(self.N):
                C_i = C_c.copy()
                if self.preview_on:
                    kap_i = track.get_curvature(s_k + i * self.dt * self.vref)
                    C_i[3] = C_c[3] - self.dt * (kap_i - kap_k) * self.vref
                d_seq.append(C_i + B_c @ ueq_c)

            A_seq = [A_c] * self.N
            B_seq = [B_c] * self.N
            ueq_tile = np.tile(ueq_c, self.N)
            u_min_vec = np.zeros(self.N * 2)
            u_max_vec = np.zeros(self.N * 2)
            for i in range(self.N):
                du_i = du_seq[i]
                u_min_vec[2 * i:2 * (i + 1)] = -self.bu + du_i - ueq_c
                u_max_vec[2 * i:2 * (i + 1)] = self.bu - du_i - ueq_c

            u_bar_warm = u_warm - ueq_tile
            u_bar_plan, feasible, _ = solve_condensed_qp_ltv(
                A_seq, B_seq, d_seq, xr, self.L.Q, self.L.R, P_c,
                by_vec, u_min_vec, u_max_vec, u_warm=u_bar_warm,
                pre_cache=self.L.qp_cache_list[jk], u_ref=ueq_tile
            )
            # Remark 13 one-step-ahead tightened corridor check against 1-step bound by_vec[0]
            if feasible:
                xr_next_pred = A_c @ xr + B_c @ u_bar_plan[:2] + d_seq[0]
                if abs(xr_next_pred[4]) > by_vec[0]:
                    feasible = False

            if feasible:
                # Eq. (30) & Eq. (35): u_k = \bar u_{0|k}^* + K^{(c)}(x_{r,k} - \bar x_{0|k}^*) + u_{eq}^{(c)}
                #                          = K^{(c)} x_{r,k} + \bar v_{0|k}^* + u_{eq}^{(c)}
                x0_nom = xr.copy()
                e0_tube = xr - x0_nom  # e_{0|k} = 0 (Eq. 31)
                u0_bar_star = u_bar_plan[:2]
                v0_star = u0_bar_star - (K_c @ x0_nom)  # \bar v_{0|k}^* := \bar u_{0|k}^* - K^{(c)} \bar x_{0|k}^*
                u_cmd = np.clip(K_c @ xr + v0_star + K_c @ e0_tube + ueq_c, -self.bu, self.bu)
                u_nom_plan = u_bar_plan + ueq_tile
                u_warm = np.roll(u_nom_plan, -2)
                u_warm[-2:] = 0.0
            else:
                # Eq. (36): Dual-policy fallback law u_k = K^{(j_k)} x_{r,k} + u_{eq}^{(j_k)} (\bar v_{0|k}^* = 0)
                n_fallbacks += 1
                v0_star = np.zeros(2)
                u_cmd = np.clip(K_c @ xr + ueq_c, -self.bu, self.bu)
                u_warm = np.zeros(self.N * 2)

            v0_star_norms.append(float(la.norm(v0_star)))
            t_qp = (time.perf_counter() - t_qp0) * 1000.0
            t_qp_list.append(t_qp)
            t_list.append(t_match + t_qp)

            u_prev = u_cmd
            u_cl[k, :] = u_cmd
            x_cl[k + 1, :], xg_cl[k + 1, :] = veh.propagate(x_cl[k, :], xg_cl[k, :], u_cmd, rng=rng)
            xr_next_actual = (x_cl[k + 1, :] - xref)[self.L.idx_r]
            xr_next_model = A_c @ xr + B_c @ u_cmd + C_c
            w_err = np.abs(xr_next_actual - xr_next_model)
            if w_err[4] <= self.L.w_bar_list[jk][4]:
                lat_cov_hits += 1
            if np.all(w_err <= self.L.w_bar_list[jk]):
                joint_cov_hits += 1

        alpha_max = float(np.max(self.L.alpha_c_list))
        r_bar_max = float(np.max(self.L.rbar_c_list))
        extra = {
            'm_act': int(self.L.m),
            'n_switches': int(n_switches),
            'n_vetoes': int(n_vetoes),
            'n_fallbacks': int(n_fallbacks),
            'lat_cov_pct': round(100.0 * float(lat_cov_hits) / float(n_steps), 2),
            'joint_cov_pct': round(100.0 * float(joint_cov_hits) / float(n_steps), 2),
            'V0': round(float(V_list[0]), 4),
            'V_max': round(float(np.max(V_list)), 4),
            'V_ult_bound': round(r_bar_max / (1.0 - alpha_max), 4),
            'v0_star_rms': round(float(np.sqrt(np.mean(np.square(v0_star_norms)))), 4),
            'v0_star_max': round(float(np.max(v0_star_norms)), 4),
            't_match_ms': round(float(np.mean(t_match_list)), 3),
            't_qp_ms': round(float(np.mean(t_qp_list)), 3),
        }
        return x_cl, u_cl, compute_traj_metrics(x_cl, veh.dt, self.by, t_list, extra=extra)


# ==============================================================================
# 5. Method 2: RHC-MPC (Gautam, Chu, & Soh, IEEE TAC 2012, Vol. 57, No. 4, pp. 973-988)
#    Full Dynamic Perturbation Policy (Fig. 1, Eqs. 10-25, Eq. 36, & Theorem 6 Eq. 40)
# ==============================================================================
class RHCMPCController:
    """
    Full equation-aligned implementation of Gautam, Chu, & Soh (IEEE TAC 2012,
    Section III, Fig. 1, pp. 975-981) over the shared m-cluster local model library:
      - Dynamic Control Policy Parameterization (Eqs. 10a-10c, p. 976):
            xi_{k+1} = G^{(c)} xi_k + F^{(c)} w_k,   xi_{k|k} = xi_k in R^{n_xi} (n_xi = 5)
            u_k      = K^{(c)} x_{r,k} + H^{(c)} xi_k + u_{eq}^{(c)}
      - Augmented Closed-Loop System (Eq. 11, p. 976):
            z_{k+1} = Psi^{(c)} z_k + D_aug^{(c)} w_k,   z_k = [x_{r,k}; xi_k] in R^{10}
            Psi^{(c)} = [[A^{(c)} + B^{(c)} K^{(c)}, B^{(c)} H^{(c)}], [0, G^{(c)}]]
            D_aug^{(c)} = [D_bar^{(c)}; F^{(c)}]
      - Offline Certificate & Cost Matrix Synthesis (Section III-B, Theorem 2 & Theorem 3
        Eqs. 14-25, pp. 977-978, and Nominal Cost Lyapunov Eq. 36, p. 980):
        1. Unconstrained LQ optimal feedback gain K^{(c)} from DARE (Algorithm 1 Step 1).
        2. S-procedure invariant ellipsoid W_env^{(c)} and admissible static feedback gain
           K_f^{(c)} with diagonal multiplier R_w^{(c)} (Tr(R_w^{(c)}) <= 1 - alpha_c)
           satisfying Eqs. (19a)-(19b):
               [K_f^{(c)} W_env^{(c)} K_f^{(c)T}]_{ii} <= (b_{u,i} - |u_{eq,i}^{(c)}|)^2.
        3. Dynamic perturbation matrices H^{(c)} = K_f^{(c)} - K^{(c)}, G^{(c)} = g_c I_5,
           F^{(c)} = -0.05 D_bar^{(c)}, and 10x10 coupled augmented invariant ellipsoid
           P_aug^{(c)} = [[W_env^{-1} + X_xi^{(c)}, -X_xi^{(c)}], [-X_xi^{(c)}, X_xi^{(c)}]]
           constructed via Theorem 3 Eqs. (24)-(25) (p. 978).
        4. Infinite-horizon nominal cost matrix P_bar^{(c)} in R^{10x10} solving Eq. (36):
               P_bar^{(c)} - Psi^{(c)T} P_bar^{(c)} Psi^{(c)} = C_z^{(c)T} C_z^{(c)} + eps * I,
           where C_z^{(c)} = [[Q^{1/2}, 0], [R^{1/2} K^{(c)}, R^{1/2} H^{(c)}]].
      - Online Receding-Horizon Optimization (Section III-C, Fig. 1 & Theorem 6 Eq. 40, p. 981):
        At each sampling instant k >= 0, given x_{r,k} and active mode c = j_k, optimize
        the perturbation state xi_k in R^5 via the shared QP solver `solve_qp_core` to
        minimize the infinite-horizon nominal cost bound Eq. (40):
               min_{xi_k}  J_bar_k = [x_{r,k}^T, xi_k^T] P_bar^{(c)} [x_{r,k}; xi_k]
               s.t.        [x_{r,k}^T, xi_k^T] P_aug^{(c)} [x_{r,k}; xi_k] <= 1,
                           -b_u <= K^{(c)} x_{r,k} + H^{(c)} xi_k + u_{eq}^{(c)} <= b_u,
        and apply the receding-horizon control input u_k^* = K^{(c)} x_{r,k} + H^{(c)} xi_k^* + u_{eq}^{(c)}.
    """
    def __init__(self, learner):
        self.L = learner
        self.K_lq = []
        self.K_rhc = []  # S-procedure static gain K_f^{(c)} (Eq. 19a-19b)
        self.H_c = []
        self.H_hat = []
        self.G_c = []
        self.F_c = []
        self.Rw_c = []
        self.alpha_c = []
        self.W_inv = []
        self.X_xi_sqrt = []
        self.X_xi_inv_sqrt = []
        self.P_aug = []
        self.P_bar = []
        self.qp_caches = []

        nx = self.L.nx
        Q_sqrt = la.sqrtm(self.L.Q).real
        R_sqrt = la.sqrtm(self.L.R).real

        for c in range(self.L.m):
            A, B = self.L.A_list[c], self.L.B_list[c]
            K_lq_c = self.L.K_list[c]
            Dbar = np.diag(self.L.Dbar_list[c])

            Xc = self.L.Xr[self.L.idx == c]
            q95_box = np.percentile(np.abs(Xc), 95.0, axis=0)
            env_box = np.maximum(q95_box, np.array([0.40, 0.40, 1.35, 0.42, 1.28 * self.L.by]))
            W_env = np.diag(env_box ** 2)
            u_avail = np.maximum(self.L.bu - np.abs(self.L.ueq_list[c]), 0.20 * self.L.bu)

            def sproc_obj(log_lam):
                lam = np.exp(log_lam)
                R_sdp = self.L.R + np.diag(lam)
                P_c = la.solve_discrete_are(A, B, self.L.Q, R_sdp)
                K_c = -la.solve(R_sdp + B.T @ P_c @ B, B.T @ P_c @ A)
                u_var = np.diag(K_c @ W_env @ K_c.T)
                viol = np.maximum(0.0, u_var - (u_avail ** 2))
                return float(np.sum(lam)) + 1e6 * float(np.sum(viol ** 2))

            res = minimize(sproc_obj, np.array([3.5, 0.0]), method='Nelder-Mead', options={'maxiter': 100})
            lam_opt = np.exp(res.x)
            R_sdp = self.L.R + np.diag(lam_opt)
            P_f = la.solve_discrete_are(A, B, self.L.Q, R_sdp)
            K_f_c = -la.solve(R_sdp + B.T @ P_f @ B, B.T @ P_f @ A)

            Acl_f = A + B @ K_f_c
            rho_f = float(np.max(np.abs(la.eigvals(Acl_f))))
            alpha = min(0.92, max(0.82, 0.5 * (rho_f ** 2 + 1.0)))
            d_vec = np.maximum(self.L.Dbar_list[c], 1e-6)
            rw_diag = (1.0 - alpha) * (d_vec / np.sum(d_vec))
            Rw = np.diag(rw_diag)

            # Theorem 3 (p. 978): H^{(c)} = K_f^{(c)} - K^{(c)}, G^{(c)} = g_c I_5, F^{(c)} = -0.05 D_bar^{(c)}
            H_mat = K_f_c - K_lq_c
            g_sc = min(0.85, max(0.25, 0.95 * min(rho_f, 0.95)))
            G_mat = g_sc * np.eye(nx)
            F_mat = -0.05 * Dbar

            Acl_lq = A + B @ K_lq_c
            X_alpha = la.solve_discrete_lyapunov(Acl_lq.T / np.sqrt(alpha), np.eye(nx))
            sigma_c = 1e6
            X_xi_c = sigma_c * X_alpha
            X_xi_sq = la.sqrtm(X_xi_c).real
            X_xi_isq = la.inv(X_xi_sq)
            W_inv_c = la.inv(W_env)
            P_aug_c = np.block([
                [W_inv_c + X_xi_c, -X_xi_c],
                [-X_xi_c,           X_xi_c]
            ])

            # Eq. (36) (p. 980): Infinite-horizon nominal cost matrix P_bar^{(c)}
            Psi_c = np.block([
                [Acl_lq,            B @ H_mat],
                [np.zeros((nx, nx)), G_mat]
            ])
            Cz_c = np.block([
                [Q_sqrt,            np.zeros((nx, nx))],
                [R_sqrt @ K_lq_c,   R_sqrt @ H_mat]
            ])
            P_bar_c = la.solve_discrete_lyapunov(Psi_c.T, Cz_c.T @ Cz_c + 1e-4 * np.eye(2 * nx))
            P_bar_c = 0.5 * (P_bar_c + P_bar_c.T)

            # Normalized perturbation coordinate xi_hat = X_xi^{1/2}(xi_k - x_{r,k}) for Theorem 6 Eq. (40)
            H_hat_c = H_mat @ X_xi_isq
            H_qp = 2.0 * (X_xi_isq.T @ P_bar_c[nx:, nx:] @ X_xi_isq) + 1e-3 * np.eye(nx)
            H_qp = 0.5 * (H_qp + H_qp.T)
            f_gain = 2.0 * X_xi_isq.T @ (P_bar_c[:nx, nx:].T + P_bar_c[nx:, nx:])
            rho_qp = 6.0
            cho_M = la.cho_factor(H_qp + rho_qp * (np.eye(nx) + H_hat_c.T @ H_hat_c))

            self.K_lq.append(K_lq_c)
            self.K_rhc.append(K_f_c)
            self.H_c.append(H_mat)
            self.H_hat.append(H_hat_c)
            self.G_c.append(G_mat)
            self.F_c.append(F_mat)
            self.Rw_c.append(Rw)
            self.alpha_c.append(alpha)
            self.W_inv.append(W_inv_c)
            self.X_xi_sqrt.append(X_xi_sq)
            self.X_xi_inv_sqrt.append(X_xi_isq)
            self.P_aug.append(P_aug_c)
            self.P_bar.append(P_bar_c)
            self.qp_caches.append({'H': H_qp, 'cho_M': cho_M, 'rho': rho_qp, 'f_gain': f_gain})

    def run_sim(self, track, veh, T=60.0, x0_offset=None, seed=42):
        n_steps = int(round(T / veh.dt))
        x_cl = np.zeros((n_steps + 1, 6))
        xg_cl = np.zeros((n_steps + 1, 6))
        u_cl = np.zeros((n_steps, 2))
        x_cl[0, 0] = veh.vt
        xg_cl[0, 0] = veh.vt
        if x0_offset is not None:
            x_cl[0, :] += x0_offset
        rng = np.random.default_rng(seed)

        ema = None
        j_prev = 0
        dwell = 0
        u_prev = np.zeros(2)
        xi_hat_warm = np.zeros(5)
        t_list = []
        xref = np.array([self.L.vref, 0.0, 0.0, 0.0, 0.0, 0.0])
        nx = self.L.nx

        for k in range(n_steps):
            t0 = time.perf_counter()
            xr = (x_cl[k, :] - xref)[self.L.idx_r]
            kap_k = track.get_curvature(x_cl[k, 4])
            jk, _, ema, _ = self.L.match_step(xr, u_prev, kap_k, ema, j_prev, dwell)
            dwell = 1 if (jk != j_prev) else (dwell + 1)
            j_prev = jk

            # Theorem 6 Eq. (40): Online optimization of xi_k in R^5 minimizing [xr_k^T, xi_k^T] P_bar [xr_k; xi_k]
            # subject to [xr_k^T, xi_k^T] P_aug [xr_k; xi_k] <= 1 and input constraints |u_k| <= b_u
            H_hat_c = self.H_hat[jk]
            K_f_c = self.K_rhc[jk]
            K_lq_c = self.K_lq[jk]
            H_mat = self.H_c[jk]
            ueq_c = self.L.ueq_list[jk]
            cache = self.qp_caches[jk]

            f_qp = cache['f_gain'] @ xr
            u_nom_f = K_f_c @ xr + ueq_c
            y_min = -self.L.bu - u_nom_f
            y_max = self.L.bu - u_nom_f

            slack = max(0.0, 1.0 - float(xr @ self.W_inv[jk] @ xr))
            rad = np.sqrt(slack)
            box_lim = np.full(nx, rad)

            xi_hat_opt = solve_qp_core(
                cache['H'], f_qp, H_hat_c, -box_lim, box_lim, y_min, y_max,
                u_warm=xi_hat_warm, cho_M=cache['cho_M'], rho=cache['rho'], cache_dict=cache
            )
            norm_sq = float(xi_hat_opt @ xi_hat_opt)
            if norm_sq > slack and norm_sq > 1e-12:
                xi_hat_opt = xi_hat_opt * (rad / np.sqrt(norm_sq))

            xi_k = xr + self.X_xi_inv_sqrt[jk] @ xi_hat_opt
            # Eq. (10c) & Eq. (40): u_k^* = K^{(c)} x_{r,k} + H^{(c)} xi_k^* + u_{eq}^{(c)}
            u_cmd = np.clip(K_lq_c @ xr + H_mat @ xi_k + ueq_c, -self.L.bu, self.L.bu)
            xi_hat_warm = self.G_c[jk] @ xi_hat_opt
            u_prev = u_cmd
            u_cl[k, :] = u_cmd
            t_list.append((time.perf_counter() - t0) * 1000.0)
            x_cl[k + 1, :], xg_cl[k + 1, :] = veh.propagate(x_cl[k, :], xg_cl[k, :], u_cmd, rng=rng)

        return x_cl, u_cl, compute_traj_metrics(x_cl, veh.dt, self.L.by, t_list)


# ==============================================================================
# 6. Method 3: LSR (Global) (Wei et al., WCICA 2010)
#    Single Global Affine Model (m=1) with Shared Q, R, DARE P0, and N=10 QP
# ==============================================================================
class GlobalLSRController:
    def __init__(self, xD, uD, kapD, dt, vref, by, bu=(0.40, 5.00)):
        self.L = TubeFMLearner(dt=dt, vref=vref, m_req=1, by=by, bu=bu).fit(xD, uD, kapD, hw=by / 0.9333)
        self.dt = float(dt)
        self.vref = float(vref)
        self.by = float(by)
        self.bu = np.array(bu, dtype=float)
        self.N = 10

    def run_sim(self, track, veh, T=60.0, x0_offset=None, seed=42):
        n_steps = int(round(T / veh.dt))
        x_cl = np.zeros((n_steps + 1, 6))
        xg_cl = np.zeros((n_steps + 1, 6))
        u_cl = np.zeros((n_steps, 2))
        x_cl[0, 0] = veh.vt
        xg_cl[0, 0] = veh.vt
        if x0_offset is not None:
            x_cl[0, :] += x0_offset
        rng = np.random.default_rng(seed)

        A0 = self.L.A_list[0]
        B0 = self.L.B_list[0]
        C0 = self.L.C_list[0]
        P0 = self.L.P_list[0]
        K0 = self.L.K_list[0]
        ueq0 = self.L.ueq_list[0]
        A_seq = [A0] * self.N
        B_seq = [B0] * self.N
        d_seq = [C0] * self.N
        by_vec = np.full(self.N, self.by)
        u_min_vec = np.tile(-self.bu, self.N)
        u_max_vec = np.tile(self.bu, self.N)

        u_warm = np.zeros(self.N * 2)
        t_list = []
        xref = np.array([self.vref, 0.0, 0.0, 0.0, 0.0, 0.0])

        for k in range(n_steps):
            t0 = time.perf_counter()
            xr = (x_cl[k, :] - xref)[self.L.idx_r]
            u_plan, feasible, _ = solve_condensed_qp_ltv(
                A_seq, B_seq, d_seq, xr, self.L.Q, self.L.R, P0,
                by_vec, u_min_vec, u_max_vec, u_warm=u_warm,
                pre_cache=self.L.qp_cache_list[0]
            )
            if feasible:
                u_cmd = np.clip(u_plan[:2], -self.bu, self.bu)
                u_warm = np.roll(u_plan, -2)
                u_warm[-2:] = 0.0
            else:
                u_cmd = np.clip(K0 @ xr + ueq0, -self.bu, self.bu)
                u_warm = np.zeros(self.N * 2)
            u_cl[k, :] = u_cmd
            t_list.append((time.perf_counter() - t0) * 1000.0)
            x_cl[k + 1, :], xg_cl[k + 1, :] = veh.propagate(x_cl[k, :], xg_cl[k, :], u_cmd, rng=rng)

        return x_cl, u_cl, compute_traj_metrics(x_cl, veh.dt, self.by, t_list)


# ==============================================================================
# 7. Method 4: Online LLSR (Rosolia & Borrelli, IEEE TCST 2020)
#    Online K-NN (K=120) Epanechnikov Kernel Weighted Local Linear Regression
# ==============================================================================
class OnlineLLSRController:
    def __init__(self, xD, uD, kapD, dt, vref, by, bu=(0.40, 5.00), K_nn=120):
        self.L_base = TubeFMLearner(dt=dt, vref=vref, m_req=1, by=by, bu=bu).fit(xD, uD, kapD, hw=by / 0.9333)
        self.dt = float(dt)
        self.vref = float(vref)
        self.by = float(by)
        self.bu = np.array(bu, dtype=float)
        self.N = 10
        self.K_nn = int(K_nn)
        self.Q = self.L_base.Q
        self.R = self.L_base.R
        self.P0 = self.L_base.P_list[0]
        self.K0 = self.L_base.K_list[0]
        stride = max(1, len(self.L_base.Xr) // 2000)
        self.X_db = self.L_base.Xr[::stride]
        self.U_db = self.L_base.Utr[::stride]
        self.Y_db = self.L_base.Yr[::stride]
        self.kap_db = self.L_base.kap[::stride]
        self.x_scale = np.std(self.X_db[:, :3], axis=0) + 1e-4

    def _fit_local_model(self, xr):
        diff = (self.X_db[:, :3] - xr[:3]) / self.x_scale
        d2 = np.sum(diff ** 2, axis=1)
        idx = np.argpartition(d2, self.K_nn)[:self.K_nn]
        d_loc = np.sqrt(d2[idx])
        h_bw = max(float(np.max(d_loc)), 1e-4)
        w = np.maximum(0.0, 1.0 - (d_loc / h_bw) ** 2) + 1e-3
        w /= np.sum(w)

        Xn = self.X_db[idx]
        Un = self.U_db[idx]
        Yn = self.Y_db[idx]
        kn = self.kap_db[idx]
        kb_loc = float(np.sum(w * kn))

        A = np.zeros((5, 5))
        B = np.zeros((5, 2))
        C_vec = np.zeros(5)
        W_sqrt = np.sqrt(w)
        # Exact 5-parameter single-input support of Rosolia & Borrelli (2020) Eqs. (13)-(14):
        # Row 0 (vx): [vx-vref, vy, wz, a, 1]; Rows 1,2 (vy, wz): [vx-vref, vy, wz, sigma, 1]
        for j_row, u_col in [(0, 1), (1, 0), (2, 0)]:
            Ri = np.column_stack([Xn[:, :3], Un[:, u_col], np.ones(len(idx))])
            Rw = Ri * W_sqrt[:, None]
            yw = Yn[:, j_row] * W_sqrt
            Wi = la.solve(Rw.T @ Rw + 1e-5 * np.eye(5), Rw.T @ yw)
            A[j_row, :3] = Wi[:3]
            B[j_row, u_col] = Wi[3]
            C_vec[j_row] = Wi[4]

        dts = self.dt
        vr = self.vref
        # Exact negative partial derivative A[3,4] = -dts * vr * (kb_loc ** 2)
        A[3, :] = np.array([-dts * kb_loc, 0.0, dts, 1.0, -dts * vr * (kb_loc ** 2)])
        C_vec[3] = -1.0 * dts * kb_loc * vr
        A[4, :] = np.array([0.0, dts, 0.0, dts * vr, 1.0])
        C_vec[4] = 0.0
        return A, B, C_vec

    def run_sim(self, track, veh, T=60.0, x0_offset=None, seed=42):
        n_steps = int(round(T / veh.dt))
        x_cl = np.zeros((n_steps + 1, 6))
        xg_cl = np.zeros((n_steps + 1, 6))
        u_cl = np.zeros((n_steps, 2))
        x_cl[0, 0] = veh.vt
        xg_cl[0, 0] = veh.vt
        if x0_offset is not None:
            x_cl[0, :] += x0_offset
        rng = np.random.default_rng(seed)

        u_warm = np.zeros(self.N * 2)
        by_vec = np.full(self.N, self.by)
        u_min_vec = np.tile(-self.bu, self.N)
        u_max_vec = np.tile(self.bu, self.N)
        t_list = []
        xref = np.array([self.vref, 0.0, 0.0, 0.0, 0.0, 0.0])

        for k in range(n_steps):
            t0 = time.perf_counter()
            xr = (x_cl[k, :] - xref)[self.L_base.idx_r]
            A_loc, B_loc, C_loc = self._fit_local_model(xr)
            u_plan, _, _ = solve_condensed_qp_ltv(
                [A_loc] * self.N, [B_loc] * self.N, [C_loc] * self.N,
                xr, self.Q, self.R, self.P0, by_vec, u_min_vec, u_max_vec, u_warm=u_warm
            )
            u_cmd = np.clip(u_plan[:2], -self.bu, self.bu)
            u_warm = np.roll(u_plan, -2)
            u_warm[-2:] = 0.0
            u_cl[k, :] = u_cmd
            t_list.append((time.perf_counter() - t0) * 1000.0)
            x_cl[k + 1, :], xg_cl[k + 1, :] = veh.propagate(x_cl[k, :], xg_cl[k, :], u_cmd, rng=rng)

        return x_cl, u_cl, compute_traj_metrics(x_cl, veh.dt, self.by, t_list)


# ==============================================================================
# 8. Method 5: Koopman MPC (Korda & Mezic, Automatica 2018)
#    12D (n_z = 5 + 7 RBFs) EDMD Linear Predictor Evolved Over All N=10 Steps
# ==============================================================================
class KoopmanMPCController:
    def __init__(self, xD, uD, kapD, dt, vref, by, bu=(0.40, 5.00), n_rbf=7):
        self.L_base = TubeFMLearner(dt=dt, vref=vref, m_req=1, by=by, bu=bu).fit(xD, uD, kapD, hw=by / 0.9333)
        self.dt = float(dt)
        self.vref = float(vref)
        self.by = float(by)
        self.bu = np.array(bu, dtype=float)
        self.N = 10
        self.Q = self.L_base.Q
        self.R = self.L_base.R
        self.P0 = self.L_base.P_list[0]
        self.n_rbf = int(n_rbf)
        self.nz = 5 + self.n_rbf  # n_z = 12 lifted state dimension (Table S-VI)

        Xr, Utr, Yr = self.L_base.Xr, self.L_base.Utr, self.L_base.Yr
        self.x_mean = np.mean(Xr[:, :3], axis=0)
        self.x_std = np.std(Xr[:, :3], axis=0) + 1e-4
        X_norm = (Xr[:, :3] - self.x_mean) / self.x_std
        _, self.centers = fb_kmeans_exact(X_norm[::3], self.n_rbf, restarts=10, seed=2025)

        Psi_X = self._lift_batch(Xr)
        Psi_Y = self._lift_batch(Yr)
        Reg = np.column_stack([Psi_X, Utr, np.ones(len(Xr))])
        Theta = la.solve(Reg.T @ Reg + 1e-2 * np.eye(self.nz + 3), Reg.T @ Psi_Y)
        self.A_lift = Theta[:self.nz, :].T
        self.B_lift = Theta[self.nz:self.nz + 2, :].T
        self.c_lift = Theta[self.nz + 2, :]
        self._build_lifted_qp_cache()

    def _lift_batch(self, X):
        X_norm = (X[:, :3] - self.x_mean) / self.x_std
        d2 = np.sum((X_norm[:, None, :] - self.centers[None, :, :]) ** 2, axis=2)
        rbf = np.exp(-0.5 * d2)
        return np.column_stack([X, rbf])

    def _lift_single(self, xr):
        x_norm = (xr[:3] - self.x_mean) / self.x_std
        d2 = np.sum((x_norm[None, :] - self.centers) ** 2, axis=1)
        rbf = np.exp(-0.5 * d2)
        return np.concatenate([xr, rbf])

    def _build_lifted_qp_cache(self):
        N, nz, nu, nx = self.N, self.nz, 2, 5
        C_proj = np.zeros((nx, nz))
        C_proj[:nx, :nx] = np.eye(nx)

        S_z = np.zeros(((N + 1) * nz, nz))
        S_u_z = np.zeros(((N + 1) * nz, N * nu))
        S_d_z = np.zeros(((N + 1) * nz, N * nz))
        S_z[:nz, :] = np.eye(nz)
        for i in range(N):
            rn = slice((i + 1) * nz, (i + 2) * nz)
            rc = slice(i * nz, (i + 1) * nz)
            S_z[rn, :] = self.A_lift @ S_z[rc, :]
            S_u_z[rn, :] = self.A_lift @ S_u_z[rc, :]
            S_u_z[rn, i * nu:(i + 1) * nu] = self.B_lift
            S_d_z[rn, :] = self.A_lift @ S_d_z[rc, :]
            S_d_z[rn, i * nz:(i + 1) * nz] = np.eye(nz)

        C_blk = la.block_diag(*([C_proj] * (N + 1)))
        self.S_x = C_blk @ S_z
        self.S_u = C_blk @ S_u_z
        self.d_projected = (C_blk @ S_d_z) @ np.tile(self.c_lift, N)
        self.Q_blk = la.block_diag(*([self.Q] * N + [self.P0]))
        R_blk = la.block_diag(*([self.R] * N))
        self.H = 0.5 * (self.S_u.T @ self.Q_blk @ self.S_u + R_blk + (self.S_u.T @ self.Q_blk @ self.S_u + R_blk).T) + 1e-7 * np.eye(N * nu)
        self.ey_rows = [i * nx + 4 for i in range(1, N + 1)]
        self.G_ey = self.S_u[self.ey_rows, :]
        self.rho = 6.0
        self.cho_M = la.cho_factor(self.H + self.rho * (np.eye(N * nu) + self.G_ey.T @ self.G_ey))
        self.qp_cache = {'H': self.H, 'cho_M': self.cho_M, 'rho': self.rho}

    def run_sim(self, track, veh, T=60.0, x0_offset=None, seed=42):
        n_steps = int(round(T / veh.dt))
        x_cl = np.zeros((n_steps + 1, 6))
        xg_cl = np.zeros((n_steps + 1, 6))
        u_cl = np.zeros((n_steps, 2))
        x_cl[0, 0] = veh.vt
        xg_cl[0, 0] = veh.vt
        if x0_offset is not None:
            x_cl[0, :] += x0_offset
        rng = np.random.default_rng(seed)

        u_warm = np.zeros(self.N * 2)
        by_vec = np.full(self.N, self.by)
        u_min_vec = np.tile(-self.bu, self.N)
        u_max_vec = np.tile(self.bu, self.N)
        t_list = []
        xref = np.array([self.vref, 0.0, 0.0, 0.0, 0.0, 0.0])

        for k in range(n_steps):
            t0 = time.perf_counter()
            xr = (x_cl[k, :] - xref)[self.L_base.idx_r]
            z0 = self._lift_single(xr)
            x_free = self.S_x @ z0 + self.d_projected
            f_qp = self.S_u.T @ (self.Q_blk @ x_free)
            ey_off = x_free[self.ey_rows]
            y_min = -by_vec - ey_off
            y_max = by_vec - ey_off

            z_u = solve_qp_core(
                self.H, f_qp, self.G_ey, u_min_vec, u_max_vec, y_min, y_max,
                u_warm=u_warm, cho_M=self.cho_M, rho=self.rho, cache_dict=self.qp_cache
            )

            u_cmd = np.clip(z_u[:2], -self.bu, self.bu)
            u_warm = np.roll(z_u, -2)
            u_warm[-2:] = 0.0
            u_cl[k, :] = u_cmd
            t_list.append((time.perf_counter() - t0) * 1000.0)
            x_cl[k + 1, :], xg_cl[k + 1, :] = veh.propagate(x_cl[k, :], xg_cl[k, :], u_cmd, rng=rng)

        return x_cl, u_cl, compute_traj_metrics(x_cl, veh.dt, self.by, t_list)


# ==============================================================================
# 9. Method 6: Dr-KMPC (Bao et al., IEEE TASE 2026)
#    Alternating BCD 8D Reduced Koopman Linear Predictor (bar_K=8, N_c=8)
# ==============================================================================
class DrKMPCController:
    def __init__(self, xD, uD, kapD, dt, vref, by, bu=(0.40, 5.00), k_red=3, n_centers=8, n_bcd_iter=15):
        self.L_base = TubeFMLearner(dt=dt, vref=vref, m_req=1, by=by, bu=bu).fit(xD, uD, kapD, hw=by / 0.9333)
        self.dt = float(dt)
        self.vref = float(vref)
        self.by = float(by)
        self.bu = np.array(bu, dtype=float)
        self.N = 10
        self.Q = self.L_base.Q
        self.R = self.L_base.R
        self.P0 = self.L_base.P_list[0]
        self.k_red = int(k_red)
        self.n_centers = int(n_centers)
        self.n_bcd_iter = int(n_bcd_iter)
        self.nz = 5 + self.k_red  # bar_K = 8 reduced Koopman coordinates

        Xr, Utr, Yr, kap = self.L_base.Xr, self.L_base.Utr, self.L_base.Yr, self.L_base.kap
        n_tr_drk = len(self.L_base.ok_mask)
        kap_next = kapD[1:n_tr_drk + 1][self.L_base.ok_mask]
        F_x = np.column_stack([Xr[:, :3], kap])
        F_y = np.column_stack([Yr[:, :3], kap_next[:len(Xr)]])
        self.f_mean = np.mean(F_x, axis=0)
        self.f_std = np.std(F_x, axis=0) + 1e-4
        Fx_norm = (F_x - self.f_mean) / self.f_std
        Fy_norm = (F_y - self.f_mean) / self.f_std
        _, self.centers = fb_kmeans_exact(Fx_norm[::3], self.n_centers, restarts=10, seed=2026)

        Phi_X = np.exp(-0.5 * np.sum((Fx_norm[:, None, :] - self.centers[None, :, :]) ** 2, axis=2))
        Phi_Y = np.exp(-0.5 * np.sum((Fy_norm[:, None, :] - self.centers[None, :, :]) ** 2, axis=2))

        cov_phi = Phi_X.T @ Phi_X / len(Phi_X)
        _, evecs = la.eigh(cov_phi)
        W_proj = evecs[:, -self.k_red:]

        for _ in range(self.n_bcd_iter):
            Z_x = np.column_stack([Xr, Phi_X @ W_proj])
            Z_y = np.column_stack([Yr, Phi_Y @ W_proj])
            Reg = np.column_stack([Z_x, Utr, np.ones(len(Xr))])
            Theta = la.solve(Reg.T @ Reg + 0.25 * np.eye(self.nz + 3), Reg.T @ Z_y)
            A_z = Theta[:self.nz, :].T
            B_z = Theta[self.nz:self.nz + 2, :].T
            c_z = Theta[self.nz + 2, :]

            A_5_red = A_z[:5, 5:]
            res_5 = Yr - (Xr @ A_z[:5, :5].T + Utr @ B_z[:5, :].T + c_z[:5][None, :])
            lhs_w = A_5_red.T @ A_5_red + 1e-2 * np.eye(self.k_red)
            rhs_w = la.lstsq(Phi_X, res_5 @ A_5_red)[0]
            W_proj = rhs_w @ la.inv(lhs_w)
            W_proj, _ = la.qr(W_proj, mode='economic')

        self.W_proj = W_proj
        self.A_z = A_z
        self.B_z = B_z
        self.c_z = c_z

    def _lift_single(self, xr, kap_k):
        f_vec = np.array([xr[0], xr[1], xr[2], kap_k])
        f_norm = (f_vec - self.f_mean) / self.f_std
        phi = np.exp(-0.5 * np.sum((f_norm[None, :] - self.centers) ** 2, axis=1))
        return np.concatenate([xr, phi @ self.W_proj])

    def run_sim(self, track, veh, T=60.0, x0_offset=None, seed=42):
        n_steps = int(round(T / veh.dt))
        x_cl = np.zeros((n_steps + 1, 6))
        xg_cl = np.zeros((n_steps + 1, 6))
        u_cl = np.zeros((n_steps, 2))
        x_cl[0, 0] = veh.vt
        xg_cl[0, 0] = veh.vt
        if x0_offset is not None:
            x_cl[0, :] += x0_offset
        rng = np.random.default_rng(seed)

        u_warm = np.zeros(self.N * 2)
        by_vec = np.full(self.N, self.by)
        u_min_vec = np.tile(-self.bu, self.N)
        u_max_vec = np.tile(self.bu, self.N)
        t_list = []
        xref = np.array([self.vref, 0.0, 0.0, 0.0, 0.0, 0.0])

        Q_z = np.zeros((self.nz, self.nz))
        Q_z[:5, :5] = self.Q
        Q_z[5:, 5:] = 1e-3 * np.eye(self.k_red)
        P_z = np.zeros((self.nz, self.nz))
        P_z[:5, :5] = self.P0
        P_z[5:, 5:] = 1e-3 * np.eye(self.k_red)
        A_seq = [self.A_z] * self.N
        B_seq = [self.B_z] * self.N
        d_seq = [self.c_z] * self.N

        for k in range(n_steps):
            t0 = time.perf_counter()
            xr = (x_cl[k, :] - xref)[self.L_base.idx_r]
            kap_k = track.get_curvature(x_cl[k, 4])
            z0 = self._lift_single(xr, kap_k)
            u_plan, _, _ = solve_condensed_qp_ltv(
                A_seq, B_seq, d_seq, z0, Q_z, self.R, P_z,
                by_vec, u_min_vec, u_max_vec, u_warm=u_warm
            )
            u_cmd = np.clip(u_plan[:2], -self.bu, self.bu)
            u_warm = np.roll(u_plan, -2)
            u_warm[-2:] = 0.0
            u_cl[k, :] = u_cmd
            t_list.append((time.perf_counter() - t0) * 1000.0)
            x_cl[k + 1, :], xg_cl[k + 1, :] = veh.propagate(x_cl[k, :], xg_cl[k, :], u_cmd, rng=rng)

        return x_cl, u_cl, compute_traj_metrics(x_cl, veh.dt, self.by, t_list)


# ==============================================================================
# 10. Method 7: Cautious GP-MPC (Hewing, Kabzan & Zeilinger, IEEE TCST 2020)
#     3-State Dynamic FITC Sparse GP (M_ind=150) over z=[vx-vref, vy, wz, sigma, a]
#     + Inducing-Point Curvature Prior + 95% Inverse-Normal Chance Tightening
# ==============================================================================
class ExactCautiousGPMPC:
    def __init__(self, xD, uD, kapD, dt, vref, by, bu=(0.40, 5.00), M_ind=150):
        self.L_base = TubeFMLearner(dt=dt, vref=vref, m_req=1, by=by, bu=bu).fit(xD, uD, kapD, hw=by / 0.9333)
        self.dt = float(dt)
        self.vref = float(vref)
        self.by = float(by)
        self.bu = np.array(bu, dtype=float)
        self.N = 10
        self.Q = self.L_base.Q
        self.R = self.L_base.R
        self.A0 = self.L_base.A_list[0].copy()
        self.B0 = self.L_base.B_list[0].copy()
        self.C0 = self.L_base.C_list[0].copy()
        self.P0 = self.L_base.P_list[0].copy()
        self.K_lqr = self.L_base.K_list[0].copy()
        self.M_ind = int(M_ind)

        # 3 independent FITC sparse GPs on the 3 dynamic velocity/yaw-rate residuals (S.F. Section II-B)
        Xr, Utr, Yr, kap = self.L_base.Xr, self.L_base.Utr, self.L_base.Yr, self.L_base.kap
        Y_res = Yr[:, :3] - (Xr @ self.A0[:3, :].T + Utr @ self.B0[:3, :].T + self.C0[:3][None, :])
        Z_full = np.column_stack([Xr[:, :3], Utr])
        self.ell = np.std(Z_full, axis=0) * 1.35 + 1e-3
        self.inv_ell2 = 1.0 / (self.ell ** 2)
        self.sf2 = np.var(Y_res, axis=0) * 1.15 + 1e-5
        self.sn2 = np.var(Y_res, axis=0) * 0.20 + 1e-5

        idx_u, self.Z_u = fb_kmeans_exact(Z_full[::2], self.M_ind, restarts=8, seed=2026)
        kap_sub = kap[::2]
        self.kap_u = np.array([
            np.mean(kap_sub[idx_u == c]) if np.any(idx_u == c) else 0.0
            for c in range(self.M_ind)
        ])
        K_uu_base = self._se_kernel(self.Z_u, self.Z_u)
        K_uf_base = self._se_kernel(self.Z_u, Z_full)

        self.alpha_list = []
        self.Q_cov_list = []
        for d in range(3):
            K_uu = self.sf2[d] * K_uu_base + 1e-5 * np.eye(self.M_ind)
            K_uf = self.sf2[d] * K_uf_base
            cho_uu = la.cho_factor(K_uu)
            K_uu_inv = la.cho_solve(cho_uu, np.eye(self.M_ind))
            V_uf = la.cho_solve(cho_uu, K_uf)
            diag_qff = np.sum(K_uf * V_uf, axis=0)
            gamma_diag = np.maximum(self.sf2[d] - diag_qff, 1e-6) + self.sn2[d]
            K_uf_gam = K_uf / gamma_diag[None, :]
            Sigma_inv = K_uu + K_uf_gam @ K_uf.T
            cho_sig = la.cho_factor(Sigma_inv)
            Sigma_inv_mat = la.cho_solve(cho_sig, np.eye(self.M_ind))
            alpha_d = Sigma_inv_mat @ (K_uf_gam @ Y_res[:, d])
            Q_cov_d = K_uu_inv - Sigma_inv_mat
            self.alpha_list.append(alpha_d)
            self.Q_cov_list.append(Q_cov_d)
        self.alpha_mat = np.column_stack(self.alpha_list)

    def _se_kernel(self, Z1, Z2):
        diff = (Z1[:, None, :] - Z2[None, :, :]) * np.sqrt(self.inv_ell2)[None, None, :]
        return np.exp(-0.5 * np.sum(diff ** 2, axis=2))

    def _eval_gp_and_jacobians(self, z_query):
        diff = self.Z_u - z_query[None, :]
        dist2 = np.sum((diff ** 2) * self.inv_ell2[None, :], axis=1)
        k_base = np.exp(-0.5 * dist2)
        kap_est = float((k_base @ self.kap_u) / (np.sum(k_base) + 1e-4))
        mu = np.zeros(3)
        var = np.zeros(3)
        jac = np.zeros((3, 5))
        for d in range(3):
            k_star = self.sf2[d] * k_base
            mu[d] = float(k_star @ self.alpha_list[d])
            v_quad = float(k_star @ self.Q_cov_list[d] @ k_star)
            var[d] = max(self.sf2[d] - v_quad, 1e-7)
            w_d = k_star * self.alpha_list[d]
            jac[d, :] = (w_d @ diff[:, :5]) * self.inv_ell2[:5]
        return mu, var, jac, kap_est

    def precompute_probabilistic_limits(self, xr0, u_nom):
        A_seq, B_seq, d_seq = [], [], []
        by_vec = np.zeros(self.N)
        u_min_vec = np.zeros(self.N * 2)
        u_max_vec = np.zeros(self.N * 2)

        x_curr = xr0.copy()
        Sigma_x = np.zeros((5, 5))
        B_d = np.vstack([np.eye(3), np.zeros((2, 3))])

        for i in range(self.N):
            u_i = u_nom[2 * i:2 * (i + 1)]
            z_i = np.concatenate([x_curr[:3], u_i])
            mu_gp, var_gp, jac_gp, kap_est = self._eval_gp_and_jacobians(z_i)

            A_i = self.A0.copy()
            B_i = self.B0.copy()
            A_i[3, :] = np.array([-self.dt * kap_est, 0.0, self.dt, 1.0, -self.dt * self.vref * (kap_est ** 2)])
            A_i[:3, :3] += jac_gp[:, :3]
            B_i[:3, :] += jac_gp[:, 3:5]

            d_i = self.C0.copy()
            d_i[3] = -self.dt * kap_est * self.vref
            d_i[:3] += mu_gp - (jac_gp[:, :3] @ x_curr[:3] + jac_gp[:, 3:5] @ u_i)

            Sigma_u = self.K_lqr @ Sigma_x @ self.K_lqr.T
            du_i = 1.96 * np.sqrt(np.maximum(np.diag(Sigma_u), 0.0))
            u_min_vec[2 * i:2 * (i + 1)] = -self.bu + du_i
            u_max_vec[2 * i:2 * (i + 1)] = self.bu - du_i

            Acl_i = A_i + B_i @ self.K_lqr
            Sigma_x = Acl_i @ Sigma_x @ Acl_i.T + B_d @ np.diag(var_gp) @ B_d.T
            dy_i = 1.96 * float(np.sqrt(max(Sigma_x[4, 4], 0.0)))
            by_vec[i] = self.by - dy_i

            x_curr = A_i @ x_curr + B_i @ u_i + d_i
            A_seq.append(A_i)
            B_seq.append(B_i)
            d_seq.append(d_i)

        return A_seq, B_seq, d_seq, by_vec, u_min_vec, u_max_vec

    def solve_nlp_slsqp(self, xr0, u_init, by_vec, u_min_vec, u_max_vec):
        def rollout_nonlinear(u_flat):
            x_seq = np.zeros((self.N + 1, 5))
            x_seq[0] = xr0
            for i in range(self.N):
                u_i = u_flat[2 * i:2 * (i + 1)]
                z_i = np.concatenate([x_seq[i, :3], u_i])
                diff = self.Z_u - z_i[None, :]
                k_base = np.exp(-0.5 * np.sum((diff ** 2) * self.inv_ell2[None, :], axis=1))
                kap_est = float((k_base @ self.kap_u) / (np.sum(k_base) + 1e-4))
                mu_gp = (self.sf2 * (k_base @ self.alpha_mat))
                A_i = self.A0.copy()
                A_i[3, :] = np.array([-self.dt * kap_est, 0.0, self.dt, 1.0, -self.dt * self.vref * (kap_est ** 2)])
                d_i = self.C0.copy()
                d_i[3] = -self.dt * kap_est * self.vref
                d_i[:3] += mu_gp
                x_seq[i + 1] = A_i @ x_seq[i] + self.B0 @ u_i + d_i
            return x_seq

        def obj_fn(u_flat):
            x_seq = rollout_nonlinear(u_flat)
            cost = 0.0
            for i in range(self.N):
                u_i = u_flat[2 * i:2 * (i + 1)]
                cost += float(x_seq[i] @ self.Q @ x_seq[i] + u_i @ self.R @ u_i)
            cost += float(x_seq[self.N] @ self.P0 @ x_seq[self.N])
            return cost

        def ineq_constr(u_flat):
            x_seq = rollout_nonlinear(u_flat)
            ey_pred = x_seq[1:, 4]
            return np.concatenate([by_vec - ey_pred, by_vec + ey_pred])

        bounds = list(zip(u_min_vec, u_max_vec))
        res = minimize(
            obj_fn, np.clip(u_init, u_min_vec, u_max_vec), method='SLSQP',
            bounds=bounds, constraints={'type': 'ineq', 'fun': ineq_constr},
            options={'maxiter': 8, 'ftol': 1e-3}
        )
        return res.x

    def run_sim(self, track, veh, T=60.0, x0_offset=None, seed=42, measure_nlp_every=20):
        n_steps = int(round(T / veh.dt))
        x_cl = np.zeros((n_steps + 1, 6))
        xg_cl = np.zeros((n_steps + 1, 6))
        u_cl = np.zeros((n_steps, 2))
        x_cl[0, 0] = veh.vt
        xg_cl[0, 0] = veh.vt
        if x0_offset is not None:
            x_cl[0, :] += x0_offset
        rng = np.random.default_rng(seed)

        u_warm = np.zeros(self.N * 2)
        t_rti_list, t_sqp_list, t_nlp_list = [], [], []
        xref = np.array([self.vref, 0.0, 0.0, 0.0, 0.0, 0.0])

        for k in range(n_steps):
            xr = (x_cl[k, :] - xref)[self.L_base.idx_r]

            # 1) Measure 1-step RTI-QP solve time independently
            t0 = time.perf_counter()
            A_seq, B_seq, d_seq, by_vec, u_min_vec, u_max_vec = self.precompute_probabilistic_limits(
                xr, u_warm
            )
            u_rti, _, _ = solve_condensed_qp_ltv(
                A_seq, B_seq, d_seq, xr, self.Q, self.R, self.P0,
                by_vec, u_min_vec, u_max_vec, u_warm=u_warm
            )
            t_rti_ms = (time.perf_counter() - t0) * 1000.0
            t_rti_list.append(t_rti_ms)

            # 2) Measure 2-step SQP solve time
            t1 = time.perf_counter()
            A_seq2, B_seq2, d_seq2, by_vec2, u_min_vec2, u_max_vec2 = self.precompute_probabilistic_limits(
                xr, u_rti
            )
            u_plan, feasible, _ = solve_condensed_qp_ltv(
                A_seq2, B_seq2, d_seq2, xr, self.Q, self.R, self.P0,
                by_vec2, u_min_vec2, u_max_vec2, u_warm=u_rti
            )
            t_sqp_ms = t_rti_ms + (time.perf_counter() - t1) * 1000.0
            t_sqp_list.append(t_sqp_ms)

            # 3) Measure direct SLSQP NLP solve time independently
            if k % measure_nlp_every == 0:
                t_nlp0 = time.perf_counter()
                _, _, _, by_n, u_min_n, u_max_n = self.precompute_probabilistic_limits(
                    xr, u_warm
                )
                _ = self.solve_nlp_slsqp(xr, u_warm, by_n, u_min_n, u_max_n)
                t_nlp_list.append((time.perf_counter() - t_nlp0) * 1000.0)

            if feasible:
                u_cmd = np.clip(u_plan[:2], -self.bu, self.bu)
                u_warm = np.roll(u_plan, -2)
                u_warm[-2:] = 0.0
            else:
                u_cmd = np.clip(self.K_lqr @ xr, -self.bu, self.bu)
                u_warm = np.zeros(self.N * 2)

            u_cl[k, :] = u_cmd
            x_cl[k + 1, :], xg_cl[k + 1, :] = veh.propagate(x_cl[k, :], xg_cl[k, :], u_cmd, rng=rng)

        extra = {
            'time_rti_qp_ms': round(float(np.mean(t_rti_list)), 2),
            'time_rti_p95_ms': round(float(np.percentile(t_rti_list, 95)), 2),
            'time_rti_p99_ms': round(float(np.percentile(t_rti_list, 99)), 2),
            'time_sqp_ms': round(float(np.mean(t_sqp_list)), 2),
            'time_nlp_slsqp_ms': round(float(np.mean(t_nlp_list)), 2),
            'time_nlp_p95_ms': round(float(np.percentile(t_nlp_list, 95)), 2),
            'time_nlp_p99_ms': round(float(np.percentile(t_nlp_list, 99)), 2),
        }
        return x_cl, u_cl, compute_traj_metrics(x_cl, veh.dt, self.by, t_sqp_list, extra=extra)


# ==============================================================================
# 11. Method 8: Exact RAMPC (Lorenzen et al., Automatica 2019; Kohler et al., 2023)
#     Full 7D Online Set-Membership Hyperbox Intersection Theta_k + Projected RLS
# ==============================================================================
class ExactRAMPC:
    def __init__(self, xD, uD, kapD, dt, vref, by, bu=(0.40, 5.00)):
        self.L_base = TubeFMLearner(dt=dt, vref=vref, m_req=1, by=by, bu=bu).fit(xD, uD, kapD, hw=by / 0.9333)
        self.dt = float(dt)
        self.vref = float(vref)
        self.by = float(by)
        self.bu = np.array(bu, dtype=float)
        self.N = 10
        self.Q = self.L_base.Q
        self.R = self.L_base.R
        self.A0 = self.L_base.A_list[0].copy()
        self.B0 = self.L_base.B_list[0].copy()
        self.C0 = self.L_base.C_list[0].copy()
        self.P0 = self.L_base.P_list[0].copy()
        self.K0 = self.L_base.K_list[0].copy()
        self.Acl0 = self.A0 + self.B0 @ self.K0

        Xr, Utr, Yr = self.L_base.Xr, self.L_base.Utr, self.L_base.Yr
        res_all = Yr - (Xr @ self.A0.T + Utr @ self.B0.T + self.C0[None, :])
        self.w_bar_noise = np.median(np.abs(res_all), axis=0)
        self.w_bar_dyn = np.percentile(np.abs(res_all[:, :4]), 95.0, axis=0)
        self.theta_0_max = np.array([
            0.12, 0.15, 0.18,
            1.2 * self.w_bar_dyn[0], 1.2 * self.w_bar_dyn[1], 1.2 * self.w_bar_dyn[2], 1.2 * self.w_bar_dyn[3]
        ])
        self.theta_0_min = -self.theta_0_max.copy()
        self.d_scale_bar = np.median(np.abs(Xr[:, :3]), axis=0)

        self.Acl_pows = [np.eye(5)]
        for _ in range(self.N):
            self.Acl_pows.append(self.Acl0 @ self.Acl_pows[-1])

    @staticmethod
    def build_D_mat(xr3):
        D = np.zeros((4, 7))
        D[0, 0] = xr3[0]
        D[1, 1] = xr3[1]
        D[2, 2] = xr3[2]
        D[0, 3] = 1.0
        D[1, 4] = 1.0
        D[2, 5] = 1.0
        D[3, 6] = 1.0
        return D

    def run_sim(self, track, veh, T=60.0, x0_offset=None, seed=42):
        n_steps = int(round(T / veh.dt))
        x_cl = np.zeros((n_steps + 1, 6))
        xg_cl = np.zeros((n_steps + 1, 6))
        u_cl = np.zeros((n_steps, 2))
        x_cl[0, 0] = veh.vt
        xg_cl[0, 0] = veh.vt
        if x0_offset is not None:
            x_cl[0, :] += x0_offset
        rng = np.random.default_rng(seed)
        u_warm = np.zeros(self.N * 2)

        theta_min = self.theta_0_min.copy()
        theta_max = self.theta_0_max.copy()
        theta_hat = np.zeros(7)
        P_rls = 0.25 * np.eye(7)
        lam_f = 0.90
        eta_drift = 0.02 * self.theta_0_max
        t_list = []

        xref = np.array([self.vref, 0.0, 0.0, 0.0, 0.0, 0.0])
        for k in range(n_steps):
            t0 = time.perf_counter()
            xr = (x_cl[k, :] - xref)[self.L_base.idx_r]
            if k > 0:
                xr_prev = (x_cl[k - 1, :] - xref)[self.L_base.idx_r]
                u_prev = u_cl[k - 1, :]
                pred_prev = self.A0 @ xr_prev + self.B0 @ u_prev + self.C0
                y_res = xr[:4] - pred_prev[:4]
                D_prev = self.build_D_mat(xr_prev[:3])

                # Causal drift + full 7-parameter set-membership hyperbox intersection Theta_k
                theta_min = np.maximum(self.theta_0_min, theta_min - eta_drift)
                theta_max = np.minimum(self.theta_0_max, theta_max + eta_drift)
                for d in range(4):
                    if d < 3 and abs(xr_prev[d]) > 0.05:
                        off_rad = 0.5 * (theta_max[3 + d] - theta_min[3 + d])
                        slope_res = (y_res[d] - theta_hat[3 + d]) / xr_prev[d]
                        slope_tol = (self.w_bar_dyn[d] + off_rad) / abs(xr_prev[d])
                        s_min = max(theta_min[d], slope_res - slope_tol)
                        s_max = min(theta_max[d], slope_res + slope_tol)
                        if s_min <= s_max:
                            theta_min[d] = s_min
                            theta_max[d] = s_max

                    rem_scale = abs(xr_prev[d]) * 0.5 * (theta_max[d] - theta_min[d]) if d < 3 else 0.0
                    hat_d = xr_prev[d] * theta_hat[d] if d < 3 else 0.0
                    low_d = y_res[d] - hat_d - (self.w_bar_dyn[d] + rem_scale)
                    high_d = y_res[d] - hat_d + (self.w_bar_dyn[d] + rem_scale)
                    new_min = max(theta_min[3 + d], low_d)
                    new_max = min(theta_max[3 + d], high_d)
                    if new_min <= new_max:
                        theta_min[3 + d] = new_min
                        theta_max[3 + d] = new_max
                    else:
                        mid = np.clip(0.5 * (low_d + high_d), self.theta_0_min[3 + d], self.theta_0_max[3 + d])
                        theta_min[3 + d] = max(self.theta_0_min[3 + d], mid - 0.5 * self.w_bar_dyn[d])
                        theta_max[3 + d] = min(self.theta_0_max[3 + d], mid + 0.5 * self.w_bar_dyn[d])

                S_rls = lam_f * np.eye(4) + D_prev @ P_rls @ D_prev.T
                K_rls = P_rls @ D_prev.T @ la.inv(S_rls)
                theta_hat = np.clip(theta_hat + K_rls @ (y_res - D_prev @ theta_hat), theta_min, theta_max)
                P_rls = (P_rls - K_rls @ D_prev @ P_rls) / lam_f + 1e-3 * np.eye(7)

            theta_rad = 0.5 * (theta_max - theta_min)
            w_tot = self.w_bar_noise.copy()
            w_tot[:3] += self.d_scale_bar * theta_rad[:3] + theta_rad[3:6]
            w_tot[3] += theta_rad[6]

            z_seq = np.zeros((self.N + 1, 5))
            du_seq = np.zeros((self.N + 1, 2))
            for i in range(self.N):
                z_seq[i + 1] = z_seq[i] + np.abs(self.Acl_pows[i]) @ w_tot
                du_seq[i + 1] = du_seq[i] + np.abs(self.K0 @ self.Acl_pows[i]) @ w_tot

            A_i = self.A0.copy()
            A_i[0, 0] += theta_hat[0]
            A_i[1, 1] += theta_hat[1]
            A_i[2, 2] += theta_hat[2]
            d_i = self.C0.copy()
            d_i[:4] += theta_hat[3:7]
            by_vec = self.by - z_seq[1:self.N + 1, 4]
            u_min_vec = np.zeros(self.N * 2)
            u_max_vec = np.zeros(self.N * 2)
            for i in range(self.N):
                u_min_vec[2 * i:2 * (i + 1)] = -self.bu + du_seq[i]
                u_max_vec[2 * i:2 * (i + 1)] = self.bu - du_seq[i]

            u_plan, feasible, _ = solve_condensed_qp_ltv(
                [A_i] * self.N, [self.B0] * self.N, [d_i] * self.N,
                xr, self.Q, self.R, self.P0, by_vec, u_min_vec, u_max_vec, u_warm=u_warm
            )
            if feasible:
                u_cmd = np.clip(u_plan[:2], -self.bu, self.bu)
                u_warm = np.roll(u_plan, -2)
                u_warm[-2:] = 0.0
            else:
                u_cmd = np.clip(self.K0 @ xr, -self.bu, self.bu)
                u_warm = np.zeros(self.N * 2)

            u_cl[k, :] = u_cmd
            t_list.append((time.perf_counter() - t0) * 1000.0)
            x_cl[k + 1, :], xg_cl[k + 1, :] = veh.propagate(x_cl[k, :], xg_cl[k, :], u_cmd, rng=rng)

        return x_cl, u_cl, compute_traj_metrics(x_cl, veh.dt, self.by, t_list)


# ==============================================================================
# 12. Publication-Quality Figure & CSV Table Generators
# ==============================================================================
METHODS_ORDER = [
    'TubeFM (Ours)', 'RHC-MPC', 'LSR (Global)', 'LLSR',
    'Koopman', 'Dr-KMPC', 'Cautious GP-MPC', 'RAMPC'
]

METHOD_COLORS = {
    'TubeFM (Ours)': '#D62728',
    'RHC-MPC': '#1F77B4',
    'LSR (Global)': '#2CA02C',
    'LLSR': '#FF7F0E',
    'Koopman': '#9467BD',
    'Dr-KMPC': '#8C564B',
    'Cautious GP-MPC': '#17BECF',
    'RAMPC': '#E377C2',
}

METHOD_STYLES = {
    'TubeFM (Ours)': ('-', 2.2),
    'RHC-MPC': ('--', 1.3),
    'LSR (Global)': ('-.', 1.3),
    'LLSR': (':', 1.4),
    'Koopman': ('--', 1.3),
    'Dr-KMPC': ('-.', 1.5),
    'Cautious GP-MPC': ('-', 1.5),
    'RAMPC': ('--', 1.5),
}


def make_3state_fig(eg_all, ec_all, jc, m_act, fname_base):
    n_show = 500
    fig, axes = plt.subplots(3, 1, figsize=(8.2, 6.8), sharex=True)
    ylabels = [r'$|e_{v_x}|$ (m/s)', r'$|e_{v_y}|$ (m/s)', r'$|e_{\omega_z}|$ (rad/s)']
    titles = [
        r'(a) Longitudinal velocity $v_x$ one-step prediction error',
        r'(b) Lateral velocity $v_y$ one-step prediction error',
        r'(c) Yaw rate $\omega_z$ one-step prediction error'
    ]
    palette = ['#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#a65628', '#f781bf', '#999999']
    t_grid = np.arange(1, n_show + 1)
    for s_idx in range(3):
        ax = axes[s_idx]
        eg = eg_all[:n_show, s_idx]
        ec = ec_all[:n_show, s_idx]
        ax.plot(t_grid, eg, color='#1f4e78', linestyle='-', linewidth=1.0,
                marker='o', markersize=2.2, alpha=0.75, label='Single global model')
        for c in range(m_act):
            idx_c = np.where(jc[:n_show] == c)[0]
            if len(idx_c) > 0:
                ax.plot(t_grid[idx_c], ec[idx_c], linestyle='None', marker='.',
                        color=palette[c % len(palette)], markersize=6.5,
                        label=f'Sub-model {c + 1}')
        ax.plot(t_grid, ec, color='#555555', linestyle='--', linewidth=0.8, alpha=0.6)
        ax.set_ylabel(ylabels[s_idx], fontsize=10, fontweight='bold')
        ax.set_title(titles[s_idx], fontsize=10.5, fontweight='bold', loc='left', pad=4)
        ax.set_xlim([0, n_show])
        ax.grid(True, linestyle=':', alpha=0.5)
        if s_idx == 0:
            ax.legend(loc='upper right', ncol=min(4, m_act + 1), fontsize=8.5, frameon=True)
    axes[-1].set_xlabel('Time step', fontsize=10.5, fontweight='bold')
    plt.tight_layout()
    fig.savefig(os.path.join(MANUSCRIPT_DIR, f'{fname_base}.pdf'), bbox_inches='tight')
    plt.close(fig)


def plot_comparison_figures(trajs_by_scen, metrics_by_scen):
    scen_list = [
        ('Nominal', 'Nominal ($\\mu=0.8, \\lambda_s=1$)', 0.70, 0.05),
        ('lam2', 'Amplified ($\\lambda_s=2, v_{x,r}=3.54$ m/s)', 1.40, 0.05 * np.sqrt(2.0)),
        ('mu06', 'Low Friction ($\\mu=0.6$)', 0.70, 0.05),
    ]

    # 1. FigCmpEy.png (plotted along arc length s [m] to match manuscript caption)
    fig, axes = plt.subplots(3, 1, figsize=(10.5, 7.8), sharex=False)
    for idx_s, (s_key, s_title, by_val, _) in enumerate(scen_list):
        ax = axes[idx_s]
        ax.axhline(by_val, color='#333333', linestyle='--', linewidth=1.1, label='Corridor bound' if idx_s == 0 else None)
        ax.axhline(-by_val, color='#333333', linestyle='--', linewidth=1.1)
        s_max = 150.0
        for m_name in METHODS_ORDER:
            x_cl = trajs_by_scen[s_key][m_name]
            s_vec = x_cl[:-1, 4]
            s_max = max(s_max, float(np.max(s_vec)))
            ls, lw = METHOD_STYLES[m_name]
            zord = 10 if m_name == 'TubeFM (Ours)' else 4
            ax.plot(s_vec, x_cl[:-1, 5], linestyle=ls, linewidth=lw, color=METHOD_COLORS[m_name],
                    label=m_name if idx_s == 0 else None, zorder=zord)
        ax.set_ylabel('$e_y$ [m]', fontsize=10.5)
        ax.set_title(s_title, fontsize=11, fontweight='bold')
        ax.grid(True, linestyle=':', alpha=0.5)
        ax.set_xlim(0, s_max)
        ax.set_ylim(-1.35 * by_val, 1.35 * by_val)
    axes[-1].set_xlabel('Arc length $s$ [m]', fontsize=11)
    axes[0].legend(loc='upper center', bbox_to_anchor=(0.5, 1.46), ncol=5, fontsize=8.8, frameon=True)
    fig.tight_layout()
    fig.savefig(os.path.join(MANUSCRIPT_DIR, 'FigCmpEy.png'), dpi=300, bbox_inches='tight')
    plt.close(fig)

    # 2. FigCmpEpsi.png (plotted along arc length s [m] to match manuscript caption)
    fig, axes = plt.subplots(3, 1, figsize=(10.5, 7.8), sharex=False)
    for idx_s, (s_key, s_title, _, _) in enumerate(scen_list):
        ax = axes[idx_s]
        s_max = 150.0
        for m_name in METHODS_ORDER:
            x_cl = trajs_by_scen[s_key][m_name]
            s_vec = x_cl[:-1, 4]
            s_max = max(s_max, float(np.max(s_vec)))
            ls, lw = METHOD_STYLES[m_name]
            zord = 10 if m_name == 'TubeFM (Ours)' else 4
            ax.plot(s_vec, Track.wrap(x_cl[:-1, 3]), linestyle=ls, linewidth=lw, color=METHOD_COLORS[m_name],
                    label=m_name if idx_s == 0 else None, zorder=zord)
        ax.set_ylabel('$e_\\psi$ [rad]', fontsize=10.5)
        ax.set_title(s_title, fontsize=11, fontweight='bold')
        ax.grid(True, linestyle=':', alpha=0.5)
        ax.set_xlim(0, s_max)
        ax.set_ylim(-0.55, 0.55)
    axes[-1].set_xlabel('Arc length $s$ [m]', fontsize=11)
    axes[0].legend(loc='upper center', bbox_to_anchor=(0.5, 1.46), ncol=5, fontsize=8.8, frameon=True)
    fig.tight_layout()
    fig.savefig(os.path.join(MANUSCRIPT_DIR, 'FigCmpEpsi.png'), dpi=300, bbox_inches='tight')
    plt.close(fig)

    # 3. FigCmpBars.png (1x4 horizontal layout)
    fig, axes = plt.subplots(1, 4, figsize=(15.4, 2.75))
    bar_specs = [
        ('rmse_ey', 'RMSE($e_y$) [m]', axes[0]),
        ('max_ey', '$\\max |e_y|$ [m]', axes[1]),
        ('rmse_epsi', 'RMSE($e_\\psi$) [rad]', axes[2]),
        ('time_ms', 'Mean Solve Time [ms]', axes[3]),
    ]
    x_pos = np.arange(3)
    width = 0.095
    for metric_key, ylabel, ax in bar_specs:
        for m_idx, m_name in enumerate(METHODS_ORDER):
            vals = [metrics_by_scen[s_key][m_name][metric_key] for s_key, _, _, _ in scen_list]
            offset = (m_idx - 3.5) * width
            ax.bar(x_pos + offset, vals, width, label=m_name, color=METHOD_COLORS[m_name], edgecolor='#222222', linewidth=0.45)
        ax.set_xticks(x_pos)
        ax.set_xticklabels(['Nominal', '$\\lambda_s=2$', '$\\mu=0.6$'], fontsize=9.0)
        ax.set_ylabel(ylabel, fontsize=9.5)
        ax.tick_params(axis='y', labelsize=8.5)
        ax.grid(True, axis='y', linestyle=':', alpha=0.55)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5, 1.04), ncol=8, fontsize=8.8, frameon=True)
    fig.tight_layout(rect=[0, 0, 1, 0.88])
    fig.savefig(os.path.join(MANUSCRIPT_DIR, 'FigCmpBars.png'), dpi=300, bbox_inches='tight')
    plt.close(fig)

    # 4. Track Trajectory Velocity Heatmaps (2x4 grid for all 8 methods)
    heat_specs = [
        ('Nominal', 2.5, 0.75, 2.5, 'FigHeatNominal.png'),
        ('lam2', 5.0, 1.50, 2.5 * np.sqrt(2.0), 'FigHeatLam2.png'),
        ('mu06', 2.5, 0.75, 2.5, 'FigHeatMu06.png'),
    ]
    for s_key, sc_scale, hw_s, vr_s, fname in heat_specs:
        trk = Track('U', scale=sc_scale, half_width=hw_s)
        s_grid = np.linspace(0, trk.track_length, 600)
        center_xy = np.array([trk.get_global_position(s, 0.0) for s in s_grid])
        left_xy = np.array([trk.get_global_position(s, hw_s * 0.9333) for s in s_grid])
        right_xy = np.array([trk.get_global_position(s, -hw_s * 0.9333) for s in s_grid])

        fig, axes = plt.subplots(2, 4, figsize=(14.5, 6.8))
        vmin, vmax = 0.80 * vr_s, 1.12 * vr_s
        lc_last = None
        for idx_m, m_name in enumerate(METHODS_ORDER):
            ax = axes[idx_m // 4, idx_m % 4]
            ax.plot(center_xy[:, 0], center_xy[:, 1], ':', color='#888888', linewidth=0.8)
            ax.plot(left_xy[:, 0], left_xy[:, 1], '--', color='#555555', linewidth=0.9)
            ax.plot(right_xy[:, 0], right_xy[:, 1], '--', color='#555555', linewidth=0.9)

            x_cl = trajs_by_scen[s_key][m_name]
            pts = np.array([trk.get_global_position(x_cl[k, 4], x_cl[k, 5]) for k in range(len(x_cl) - 1)])
            vx_vals = x_cl[:-1, 0]
            segs = np.stack([pts[:-1], pts[1:]], axis=1)
            lc = LineCollection(segs, cmap='turbo', norm=plt.Normalize(vmin, vmax), linewidths=2.0)
            lc.set_array(vx_vals[:-1])
            ax.add_collection(lc)
            lc_last = lc

            mt = metrics_by_scen[s_key][m_name]
            ax.set_title(f"{m_name}\nRMSE($e_y$)={mt['rmse_ey']:.3f}m, Viol={mt['viol_pct']:.1f}%", fontsize=9.2, fontweight='bold')
            ax.set_aspect('equal', adjustable='datalim')
            ax.tick_params(labelsize=8)
            ax.grid(True, linestyle=':', alpha=0.4)

        cbar_ax = fig.add_axes([0.92, 0.15, 0.015, 0.70])
        cb = fig.colorbar(lc_last, cax=cbar_ax)
        cb.set_label('Longitudinal Speed $v_x$ [m/s]', fontsize=10)
        fig.subplots_adjust(left=0.04, right=0.90, top=0.90, bottom=0.08, wspace=0.22, hspace=0.28)
        fig.savefig(os.path.join(MANUSCRIPT_DIR, fname), dpi=300, bbox_inches='tight')
        plt.close(fig)


def export_all_csv_tables(all_results):
    bm = all_results['benchmark_8methods']

    # 1. Table_III_Lateral_Tracking_Error_and_Safety_Margin.csv
    with open(os.path.join(DATA_DIR, 'Table_III_Lateral_Tracking_Error_and_Safety_Margin.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([
            'Method',
            'Nominal_RMSE_ey_m', 'Nominal_Max_ey_m', 'Nominal_Min_Margin_m',
            'Lam2_RMSE_ey_m', 'Lam2_Max_ey_m', 'Lam2_Min_Margin_m',
            'Mu06_RMSE_ey_m', 'Mu06_Max_ey_m', 'Mu06_Min_Margin_m'
        ])
        for m in METHODS_ORDER:
            w.writerow([
                m,
                bm['Nominal'][m]['rmse_ey'], bm['Nominal'][m]['max_ey'], bm['Nominal'][m]['min_corridor_margin_m'],
                bm['lam2'][m]['rmse_ey'], bm['lam2'][m]['max_ey'], bm['lam2'][m]['min_corridor_margin_m'],
                bm['mu06'][m]['rmse_ey'], bm['mu06'][m]['max_ey'], bm['mu06'][m]['min_corridor_margin_m'],
            ])

    # 2. Table_IV_Heading_Tracking_Error_and_Constraint_Violations.csv
    with open(os.path.join(DATA_DIR, 'Table_IV_Heading_Tracking_Error_and_Constraint_Violations.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([
            'Method',
            'Nominal_RMSE_epsi_rad', 'Nominal_Max_epsi_rad', 'Nominal_Viol_Pct',
            'Lam2_RMSE_epsi_rad', 'Lam2_Max_epsi_rad', 'Lam2_Viol_Pct',
            'Mu06_RMSE_epsi_rad', 'Mu06_Max_epsi_rad', 'Mu06_Viol_Pct'
        ])
        for m in METHODS_ORDER:
            w.writerow([
                m,
                bm['Nominal'][m]['rmse_epsi'], bm['Nominal'][m]['max_epsi'], bm['Nominal'][m]['viol_pct'],
                bm['lam2'][m]['rmse_epsi'], bm['lam2'][m]['max_epsi'], bm['lam2'][m]['viol_pct'],
                bm['mu06'][m]['rmse_epsi'], bm['mu06'][m]['max_epsi'], bm['mu06'][m]['viol_pct'],
            ])

    # 3. Table_V_Closed_Loop_Solve_Time_Comparison.csv
    with open(os.path.join(DATA_DIR, 'Table_V_Closed_Loop_Solve_Time_Comparison.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([
            'Method',
            'Nominal_Mean_ms', 'Nominal_P95_ms', 'Nominal_P99_ms',
            'Lam2_Mean_ms', 'Lam2_P95_ms', 'Lam2_P99_ms',
            'Mu06_Mean_ms', 'Mu06_P95_ms', 'Mu06_P99_ms'
        ])
        for m in METHODS_ORDER:
            w.writerow([
                m,
                bm['Nominal'][m]['time_ms'], bm['Nominal'][m]['time_p95_ms'], bm['Nominal'][m]['time_p99_ms'],
                bm['lam2'][m]['time_ms'], bm['lam2'][m]['time_p95_ms'], bm['lam2'][m]['time_p99_ms'],
                bm['mu06'][m]['time_ms'], bm['mu06'][m]['time_p95_ms'], bm['mu06'][m]['time_p99_ms'],
            ])

    # 4. Table_SI_One_Step_Prediction_Validation.csv
    with open(os.path.join(DATA_DIR, 'Table_SI_One_Step_Prediction_Validation.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([
            'Model', 'State',
            'clean_rms_500', 'clean_max_500', 'clean_rms_full', 'clean_max_full',
            'noisy_rms_500', 'noisy_max_500', 'noisy_rms_full', 'noisy_max_full'
        ])
        for mod_label, mod_dict in all_results['one_step_3state'].items():
            for st_name in ['vx', 'vy', 'wz']:
                d = mod_dict[st_name]
                w.writerow([
                    mod_label, st_name,
                    d['clean_rms_500'], d['clean_max_500'], d['clean_rms_full'], d['clean_max_full'],
                    d['noisy_rms_500'], d['noisy_max_500'], d['noisy_rms_full'], d['noisy_max_full']
                ])

    # 5. Table_SII_Cluster_Count_Sensitivity.csv
    with open(os.path.join(DATA_DIR, 'Table_SII_Cluster_Count_Sensitivity.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([
            'Clusters_m', 'm_act', 'rms_vx', 'rms_vy', 'rms_wz',
            'dbar_ey', 'rmse_ey', 'max_ey', 'rmse_epsi', 'viol_pct', 'time_ms'
        ])
        for m_k, d in all_results['m_sweep'].items():
            w.writerow([
                m_k, d['m_act'], d['rms_vx'], d['rms_vy'], d['rms_wz'],
                d['dbar_ey'], d['rmse_ey'], d['max_ey'], d['rmse_epsi'], d['viol_pct'], d['time_ms']
            ])

    # 6. Table_SIII_OOD_Robustness.csv
    with open(os.path.join(DATA_DIR, 'Table_SIII_OOD_Robustness.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([
            'Condition', 'rmse_ey', 'max_ey', 'rmse_epsi', 'max_epsi',
            'min_corridor_margin_m', 'lat_cov_pct', 'joint_cov_pct', 'viol_pct', 'time_ms', 'time_p99_ms'
        ])
        for cond, d in all_results['ood_stress'].items():
            w.writerow([
                cond, d['rmse_ey'], d['max_ey'], d['rmse_epsi'], d['max_epsi'],
                d['min_corridor_margin_m'], d['lat_cov_pct'], d['joint_cov_pct'], d['viol_pct'], d['time_ms'], d['time_p99_ms']
            ])

    # 7. Table_SIV_Feature_Vector_Ablation.csv
    with open(os.path.join(DATA_DIR, 'Table_SIV_Feature_Vector_Ablation.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([
            'Feature_Configuration', 'm_act', 'vx_clean_rms_1e3', 'vx_noisy_rms_1e3',
            'rmse_ey', 'max_ey', 'rmse_epsi', 'min_corridor_margin_m', 'n_switches', 'time_ms'
        ])
        for cfg, d in all_results['feature_sensitivity'].items():
            w.writerow([
                cfg, d['m_act'], d['vx_clean_rms_1e3'], d['vx_noisy_rms_1e3'],
                d['rmse_ey'], d['max_ey'], d['rmse_epsi'], d['min_corridor_margin_m'], d['n_switches'], d['time_ms']
            ])

    # 8. Table_SV_Dwell_Veto_and_Startup_Recovery.csv
    with open(os.path.join(DATA_DIR, 'Table_SV_Dwell_Veto_and_Startup_Recovery.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([
            'Configuration', 'rmse_ey', 'max_ey', 'rmse_epsi',
            'min_corridor_margin_m', 'n_switches', 'n_vetoes', 'n_fallbacks', 'V0', 'viol_pct', 'time_ms'
        ])
        for cfg, d in all_results['veto_startup'].items():
            w.writerow([
                cfg, d['rmse_ey'], d['max_ey'], d['rmse_epsi'],
                d['min_corridor_margin_m'], d['n_switches'], d['n_vetoes'], d['n_fallbacks'], d['V0'], d['viol_pct'], d['time_ms']
            ])

    # 9. Table_SVI_Runtime_Breakdown_and_Scaling.csv
    with open(os.path.join(DATA_DIR, 'Table_SVI_Runtime_Breakdown_and_Scaling.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Configuration', 'm_act', 't_match_ms', 't_qp_ms', 't_total_ms', 't_p95_ms', 't_p99_ms'])
        for cfg, d in all_results['runtime_scaling'].items():
            w.writerow([cfg, d['m_act'], d['t_match_ms'], d['t_qp_ms'], d['t_total_ms'], d['t_p95_ms'], d['t_p99_ms']])

    # 10. Table_SVII_Distance_Metric_Comparison.csv
    with open(os.path.join(DATA_DIR, 'Table_SVII_Distance_Metric_Comparison.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Cluster_Setting', 'Metric', 'Scenario', 'rmse_ey', 'max_ey', 'rmse_epsi', 'n_switches', 'time_ms'])
        for c_set, m_dict in all_results['distance_metric_cmp'].items():
            for m_label, s_dict in m_dict.items():
                for scen, d in s_dict.items():
                    w.writerow([c_set, m_label, scen, d['rmse_ey'], d['max_ey'], d['rmse_epsi'], d['n_switches'], d['time_ms']])


# ==============================================================================
# 13. Master Execution Pipeline
# ==============================================================================
def run_solver_equivalence_check(scenarios_data=None):
    """
    Side-by-side verification of QP solver backends ('admm', 'scipy_slsqp',
    and 'osqp' if installed) across the QP-based controllers on the Nominal scenario.
    """
    if scenarios_data is None:
        scenarios_data = load_or_generate_all_scenarios(force_regen=False)
    d = scenarios_data['Nominal']
    xD, uD, kapD = d['xD'], d['uD'], d['kapD']
    dt_s, vr_s, sc_scale, hw_s, mu_s = 0.05, 2.5, 2.5, 0.75, 0.8
    by_s = 0.9333 * hw_s
    x0_off = np.array([0.0, 0.0, 0.0, -0.02, 0.0, 0.05])

    backends = ['admm', 'scipy_slsqp']
    for ext_pkg in ('osqp', 'quadprog', 'cvxopt'):
        try:
            __import__(ext_pkg)
            backends.append(ext_pkg)
        except ImportError:
            pass
    if 'osqp' not in backends:
        print("[Info] External C-extension `osqp` (`quadprog`/`cvxopt`) not installed in sandbox; comparing built-in `admm` vs `scipy_slsqp` across all 8 controllers.")
        print("       On your local machine, run `pip install osqp` (or `quadprog`/`cvxopt`) to include them automatically.")

    prev_backend = get_qp_backend()
    print("\n=== Cross-Solver Equivalence Verification Across All 8 Controllers (Nominal Scenario) ===")
    print(f"{'Controller':<22} | {'Solver Backend':<14} | {'RMSE(ey) [m]':<13} | {'max|ey| [m]':<12} | {'RMSE(epsi)':<11} | {'Viol [%]':<9} | {'Mean Time [ms]'}")
    print("-" * 105)
    solver_cmp_records = []
    for b in backends:
        set_qp_backend(b)
        trk = Track('U', scale=sc_scale, half_width=hw_s)
        veh = Vehicle(dt_s, vr_s, trk, m=1.98, lf=0.125, lr=0.125, Iz=0.024,
                      mu=mu_s, delta_max=0.40, acc_max=5.00, sig_vx=0.004, sig_vy=0.004, sig_wz=0.002)
        tf_ctrl = TubeFMLPCController(xD, uD, kapD, dt_s, vr_s, by_s, m_req=4)
        controllers = [
            ('TubeFM (Ours)', tf_ctrl),
            ('RHC-MPC', RHCMPCController(tf_ctrl.L)),
            ('LSR (Global)', GlobalLSRController(xD, uD, kapD, dt_s, vr_s, by_s)),
            ('LLSR', OnlineLLSRController(xD, uD, kapD, dt_s, vr_s, by_s)),
            ('Koopman', KoopmanMPCController(xD, uD, kapD, dt_s, vr_s, by_s)),
            ('Dr-KMPC', DrKMPCController(xD, uD, kapD, dt_s, vr_s, by_s)),
            ('Cautious GP-MPC', ExactCautiousGPMPC(xD, uD, kapD, dt_s, vr_s, by_s, M_ind=150)),
            ('RAMPC', ExactRAMPC(xD, uD, kapD, dt_s, vr_s, by_s)),
        ]
        for c_name, ctrl in controllers:
            _, _, mt = ctrl.run_sim(trk, veh, T=60.0, x0_offset=x0_off, seed=42)
            print(f"{c_name:<22} | {b:<14} | {mt['rmse_ey']:<13.4f} | {mt['max_ey']:<12.4f} | {mt['rmse_epsi']:<11.4f} | {mt['viol_pct']:<9.2f} | {mt['time_ms']:.2f}")
            solver_cmp_records.append({
                'controller': c_name,
                'solver_backend': b,
                'rmse_ey': mt['rmse_ey'],
                'max_ey': mt['max_ey'],
                'rmse_epsi': mt['rmse_epsi'],
                'max_epsi': mt['max_epsi'],
                'viol_pct': mt['viol_pct'],
                'mean_vx': mt['mean_vx'],
                'time_ms': mt['time_ms'],
            })
    set_qp_backend(prev_backend)
    with open(os.path.join(DATA_DIR, 'qp_solver_fairness_comparison.json'), 'w') as f:
        json.dump(solver_cmp_records, f, indent=2)
    with open(os.path.join(DATA_DIR, 'Table_Solver_Equivalence_Verification.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Controller', 'Solver_Backend', 'rmse_ey', 'max_ey', 'rmse_epsi', 'max_epsi', 'viol_pct', 'mean_vx', 'time_ms'])
        for r in solver_cmp_records:
            w.writerow([r['controller'], r['solver_backend'], r['rmse_ey'], r['max_ey'], r['rmse_epsi'], r['max_epsi'], r['viol_pct'], r['mean_vx'], r['time_ms']])


def main(qp_solver=None, compare_solvers=False):
    import argparse
    if qp_solver is None and not compare_solvers:
        parser = argparse.ArgumentParser(description="TubeFM-LPC Complete Verification & Reproduction Suite")
        parser.add_argument(
            "--qp-solver",
            type=str,
            default=os.environ.get("TUBEFM_QP_SOLVER", "admm"),
            choices=list(SUPPORTED_QP_BACKENDS),
            help="Shared convex QP solver backend for all QP-based methods: 'admm' (default built-in OSQP ADMM), 'osqp' (native C-extension `pip install osqp`), or 'scipy_slsqp'.",
        )
        parser.add_argument(
            "--compare-qp-solvers",
            action="store_true",
            help="Run a side-by-side solver equivalence test across 'admm', 'scipy_slsqp', and 'osqp' (if installed) and exit.",
        )
        args, _ = parser.parse_known_args()
        qp_solver = args.qp_solver
        compare_solvers = args.compare_qp_solvers

    if compare_solvers:
        run_solver_equivalence_check()
        return

    if qp_solver is not None:
        set_qp_backend(qp_solver)
    print(f"=== Active Shared QP Solver Backend across All Methods: {get_qp_backend().upper()} ===")
    print("=== Step 0: Loading Self-Contained Identification Data ===")
    scenarios_data = load_or_generate_all_scenarios(force_regen=False)
    d_base = scenarios_data['Nominal']
    xD0, uD0, kapD0, Y_clean0 = d_base['xD'], d_base['uD'], d_base['kapD'], d_base['Y_clean']
    xref0 = np.array([2.5, 0.0, 0.0, 0.0, 0.0, 0.0])

    all_results = {}

    # ------------------------------------------------------------------
    # Part 1: 3-State One-Step Prediction Verification (Table S-I & Figs 3-4)
    # ------------------------------------------------------------------
    print("=== Step 1: 3-State One-Step Prediction Verification & Figs 3-4 ===")
    one_step_res = {}
    errs_clean_by_m = {}
    errs_noisy_by_m = {}
    j_seq_by_m = {}
    m_act_by_m = {}

    for m_req, label in [(1, 'Single (m=1)'), (4, 'Matched (m=4)'), (8, 'Matched (m=8)')]:
        L = TubeFMLearner(dt=0.05, vref=2.5, m_req=m_req, coupled_dyn=False).fit(xD0, uD0, kapD0)
        Xr, Utr, Yr, kap = L.Xr, L.Utr, L.Yr, L.kap
        Yr_clean = (Y_clean0 - xref0)[L.ok_mask][:, L.idx_r]
        errs_noisy = np.zeros((len(Xr), 3))
        errs_clean = np.zeros((len(Xr), 3))
        j_seq = np.zeros(len(Xr), dtype=int)
        ema = None
        j_prev = -1
        dwell = 0
        for k in range(len(Xr)):
            jk, _, ema, _ = L.match_step(Xr[k], Utr[k], kap[k], ema, j_prev, dwell)
            dwell = 1 if (jk != j_prev) else (dwell + 1)
            j_prev = jk
            j_seq[k] = jk
            pred = L.A_list[jk][:3, :] @ Xr[k] + L.B_list[jk][:3, :] @ Utr[k] + L.C_list[jk][:3]
            errs_noisy[k] = np.abs(pred - Yr[k, :3])
            errs_clean[k] = np.abs(pred - Yr_clean[k, :3])

        errs_clean_by_m[m_req] = errs_clean
        errs_noisy_by_m[m_req] = errs_noisy
        j_seq_by_m[m_req] = j_seq
        m_act_by_m[m_req] = L.m

        one_step_res[label] = {
            'm_act': int(L.m),
            'cluster_counts': [int(np.sum(L.idx == c)) for c in range(L.m)],
            'mean_cond_5p': round(float(np.mean(L.cond_5p_list)), 2),
            'mean_cond_6p': round(float(np.mean(L.cond_6p_list)), 2),
        }
        for s_idx, nm in enumerate(['vx', 'vy', 'wz']):
            one_step_res[label][nm] = {
                'clean_rms_500': round(float(np.sqrt(np.mean(errs_clean[:500, s_idx] ** 2))), 6),
                'clean_max_500': round(float(np.max(errs_clean[:500, s_idx])), 6),
                'clean_rms_full': round(float(np.sqrt(np.mean(errs_clean[:, s_idx] ** 2))), 6),
                'clean_max_full': round(float(np.max(errs_clean[:, s_idx])), 6),
                'noisy_rms_500': round(float(np.sqrt(np.mean(errs_noisy[:500, s_idx] ** 2))), 6),
                'noisy_max_500': round(float(np.max(errs_noisy[:500, s_idx])), 6),
                'noisy_rms_full': round(float(np.sqrt(np.mean(errs_noisy[:, s_idx] ** 2))), 6),
                'noisy_max_full': round(float(np.max(errs_noisy[:, s_idx])), 6),
            }
        print(f"  {label} (m_act={L.m}, counts={one_step_res[label]['cluster_counts']}): "
              f"vx noisy_rms_500={one_step_res[label]['vx']['noisy_rms_500']*1e3:.2f}e-3 "
              f"(clean={one_step_res[label]['vx']['clean_rms_500']*1e3:.2f}e-3), "
              f"vy clean_rms_500={one_step_res[label]['vy']['clean_rms_500']*1e3:.2f}e-3, "
              f"wz clean_rms_500={one_step_res[label]['wz']['clean_rms_500']*1e3:.2f}e-3")

    # Plot Fig-3vx.pdf (m=4 -> 3 active sub-models) and Fig-4vx.pdf (m=8 -> 6 active sub-models)
    make_3state_fig(errs_noisy_by_m[1], errs_noisy_by_m[4], j_seq_by_m[4], m_act_by_m[4], 'Fig-3vx')
    make_3state_fig(errs_noisy_by_m[1], errs_noisy_by_m[8], j_seq_by_m[8], m_act_by_m[8], 'Fig-4vx')

    # Holdout 70/30 calibration check (evaluating both q99 and w_bar == d_bar)
    n_cal = int(0.70 * len(xD0))
    L_cal = TubeFMLearner(dt=0.05, vref=2.5, m_req=4, coupled_dyn=False).fit(xD0[:n_cal + 1], uD0[:n_cal], kapD0[:n_cal + 1])
    Xd_test = xD0[n_cal:] - xref0
    Xr_test = Xd_test[:-1, L_cal.idx_r]
    Yr_test = Xd_test[1:, L_cal.idx_r]
    U_test = uD0[n_cal:-1]
    kap_test = kapD0[n_cal:-1]
    cov_q99 = np.zeros((len(Xr_test), 5), dtype=bool)
    cov_dbar = np.zeros((len(Xr_test), 5), dtype=bool)
    cov_wbar = np.zeros((len(Xr_test), 5), dtype=bool)
    ema = None; j_prev = -1; dwell = 0
    for k in range(len(Xr_test)):
        jk, _, ema, _ = L_cal.match_step(Xr_test[k], U_test[k], kap_test[k], ema, j_prev, dwell)
        dwell = 1 if (jk != j_prev) else (dwell + 1); j_prev = jk
        w_hat = np.abs(Yr_test[k] - (L_cal.A_list[jk] @ Xr_test[k] + L_cal.B_list[jk] @ U_test[k] + L_cal.C_list[jk]))
        cov_q99[k] = (w_hat <= L_cal.q_pct_list[jk])
        cov_dbar[k] = (w_hat <= L_cal.Dbar_list[jk])
        cov_wbar[k] = (w_hat <= L_cal.w_bar_list[jk])
    all_results['holdout_70_30'] = {
        'q99_per_dim_pct': [round(float(x), 2) for x in 100.0 * np.mean(cov_q99, axis=0)],
        'q99_joint_pct': round(float(100.0 * np.mean(np.all(cov_q99, axis=1))), 2),
        'dbar_per_dim_pct': [round(float(x), 2) for x in 100.0 * np.mean(cov_dbar, axis=0)],
        'dbar_joint_pct': round(float(100.0 * np.mean(np.all(cov_dbar, axis=1))), 2),
        'wbar_per_dim_pct': [round(float(x), 2) for x in 100.0 * np.mean(cov_wbar, axis=0)],
        'wbar_joint_pct': round(float(100.0 * np.mean(np.all(cov_wbar, axis=1))), 2),
    }
    all_results['one_step_3state'] = one_step_res

    # ------------------------------------------------------------------
    # Part 2: 8-Method Closed-Loop Benchmark (Tables III, IV, V & Figures)
    # ------------------------------------------------------------------
    print("\n=== Step 2: 8-Method Closed-Loop Benchmark Across 3 Scenarios ===")
    x0_off = np.array([0.0, 0.0, 0.0, -0.02, 0.0, 0.05])
    trajs_by_scen = {}
    inputs_by_scen = {}
    metrics_by_scen = {}
    lyap_cert_by_scen = {}

    for scen, dt_s, vr_s, sc_scale, hw_s, mu_s, T_s in [
        ('Nominal', 0.05, 2.5, 2.5, 0.75, 0.8, 60.0),
        ('lam2', 0.05 * np.sqrt(2.0), 2.5 * np.sqrt(2.0), 5.0, 1.50, 0.8, 60.0),
        ('mu06', 0.05, 2.5, 2.5, 0.75, 0.6, 60.0),
    ]:
        lam_s = sc_scale / 2.5
        m_veh = 1.98 * (lam_s ** 3)
        lf_veh = 0.125 * lam_s
        lr_veh = 0.125 * lam_s
        Iz_veh = 0.024 * (lam_s ** 5)

        d_arch = scenarios_data[scen]
        xD, uD, kapD = d_arch['xD'], d_arch['uD'], d_arch['kapD']
        trk = Track('U', scale=sc_scale, half_width=hw_s)
        veh = Vehicle(
            dt_s, vr_s, trk, m=m_veh, lf=lf_veh, lr=lr_veh, Iz=Iz_veh,
            mu=mu_s, delta_max=0.40, acc_max=5.00,
            sig_vx=0.004, sig_vy=0.004, sig_wz=0.002
        )
        by_s = 0.9333 * hw_s
        bu_s = (0.40, 5.00)

        trajs_by_scen[scen] = {}
        inputs_by_scen[scen] = {}
        metrics_by_scen[scen] = {}

        tf_ctrl = TubeFMLPCController(xD, uD, kapD, dt_s, vr_s, by_s, bu=bu_s)
        x_tf, u_tf, m_tf = tf_ctrl.run_sim(trk, veh, T=T_s, x0_offset=x0_off)
        trajs_by_scen[scen]['TubeFM (Ours)'] = x_tf
        inputs_by_scen[scen]['TubeFM (Ours)'] = u_tf
        metrics_by_scen[scen]['TubeFM (Ours)'] = m_tf
        lyap_cert_by_scen[scen] = {
            'm_act': int(tf_ctrl.L.m),
            'cluster_counts': [int(np.sum(tf_ctrl.L.idx == c)) for c in range(tf_ctrl.L.m)],
            'kappa_bar': [round(float(x), 4) for x in tf_ctrl.L.kappa_bar],
            'rho_c': [round(float(x), 4) for x in tf_ctrl.L.rho_c_list],
            'alpha_c': [round(float(x), 4) for x in tf_ctrl.L.alpha_c_list],
            'rbar_c': [round(float(x), 4) for x in tf_ctrl.L.rbar_c_list],
            'z_N_ey_m': [round(float(z[-1, 4]), 4) for z in tf_ctrl.L.tube_z_list],
            'by_minus_z_N_ey_m': [round(float(by_s - z[-1, 4]), 4) for z in tf_ctrl.L.tube_z_list],
        }

        rhc = RHCMPCController(tf_ctrl.L)
        x_rhc, u_rhc, m_rhc = rhc.run_sim(trk, veh, T=T_s, x0_offset=x0_off)
        trajs_by_scen[scen]['RHC-MPC'] = x_rhc
        inputs_by_scen[scen]['RHC-MPC'] = u_rhc
        metrics_by_scen[scen]['RHC-MPC'] = m_rhc

        gl = GlobalLSRController(xD, uD, kapD, dt_s, vr_s, by_s, bu=bu_s)
        x_gl, u_gl, m_gl = gl.run_sim(trk, veh, T=T_s, x0_offset=x0_off)
        trajs_by_scen[scen]['LSR (Global)'] = x_gl
        inputs_by_scen[scen]['LSR (Global)'] = u_gl
        metrics_by_scen[scen]['LSR (Global)'] = m_gl

        llsr = OnlineLLSRController(xD, uD, kapD, dt_s, vr_s, by_s, bu=bu_s)
        x_llsr, u_llsr, m_llsr = llsr.run_sim(trk, veh, T=T_s, x0_offset=x0_off)
        trajs_by_scen[scen]['LLSR'] = x_llsr
        inputs_by_scen[scen]['LLSR'] = u_llsr
        metrics_by_scen[scen]['LLSR'] = m_llsr

        koop = KoopmanMPCController(xD, uD, kapD, dt_s, vr_s, by_s, bu=bu_s, n_rbf=7)
        x_koop, u_koop, m_koop = koop.run_sim(trk, veh, T=T_s, x0_offset=x0_off)
        trajs_by_scen[scen]['Koopman'] = x_koop
        inputs_by_scen[scen]['Koopman'] = u_koop
        metrics_by_scen[scen]['Koopman'] = m_koop

        drk = DrKMPCController(xD, uD, kapD, dt_s, vr_s, by_s, bu=bu_s)
        x_drk, u_drk, m_drk = drk.run_sim(trk, veh, T=T_s, x0_offset=x0_off)
        trajs_by_scen[scen]['Dr-KMPC'] = x_drk
        inputs_by_scen[scen]['Dr-KMPC'] = u_drk
        metrics_by_scen[scen]['Dr-KMPC'] = m_drk

        gp = ExactCautiousGPMPC(xD, uD, kapD, dt_s, vr_s, by_s, bu=bu_s, M_ind=150)
        x_gp, u_gp, m_gp = gp.run_sim(trk, veh, T=T_s, x0_offset=x0_off)
        trajs_by_scen[scen]['Cautious GP-MPC'] = x_gp
        inputs_by_scen[scen]['Cautious GP-MPC'] = u_gp
        metrics_by_scen[scen]['Cautious GP-MPC'] = m_gp

        ra = ExactRAMPC(xD, uD, kapD, dt_s, vr_s, by_s, bu=bu_s)
        x_ra, u_ra, m_ra = ra.run_sim(trk, veh, T=T_s, x0_offset=x0_off)
        trajs_by_scen[scen]['RAMPC'] = x_ra
        inputs_by_scen[scen]['RAMPC'] = u_ra
        metrics_by_scen[scen]['RAMPC'] = m_ra

        print(f"\n--- {scen} (TubeFM m_act={m_tf['m_act']}, joint_cov={m_tf['joint_cov_pct']}%, lat_cov={m_tf['lat_cov_pct']}%) ---")
        for m_name in METHODS_ORDER:
            mt = metrics_by_scen[scen][m_name]
            extra_str = ""
            if 'time_nlp_slsqp_ms' in mt:
                extra_str = f" [1-step RTI-QP={mt['time_rti_qp_ms']:.2f}ms, 2-step SQP={mt['time_sqp_ms']:.2f}ms, SLSQP NLP={mt['time_nlp_slsqp_ms']:.2f}ms]"
            print(f"  {m_name:16s}: RMSE(ey)={mt['rmse_ey']:.4f}, max|ey|={mt['max_ey']:.4f}, RMSE(epsi)={mt['rmse_epsi']:.4f}, viol={mt['viol_pct']:.2f}%, vx={mt['mean_vx']:.3f}, time={mt['time_ms']:.2f}ms (p99={mt['time_p99_ms']:.2f}){extra_str}")

    all_results['benchmark_8methods'] = metrics_by_scen
    all_results['lyapunov_and_tube_certificates'] = lyap_cert_by_scen
    plot_comparison_figures(trajs_by_scen, metrics_by_scen)

    # Save all 24 closed-loop trajectories (8 methods x 3 scenarios) so every step is directly verifiable
    traj_archive = {}
    for scen in ['Nominal', 'lam2', 'mu06']:
        for m_name in METHODS_ORDER:
            safe_key = m_name.replace(' ', '_').replace('(', '').replace(')', '').replace('-', '_')
            traj_archive[f"{scen}_{safe_key}_x"] = trajs_by_scen[scen][m_name]
            traj_archive[f"{scen}_{safe_key}_u"] = inputs_by_scen[scen][m_name]
    np.savez_compressed(os.path.join(DATA_DIR, 'closed_loop_trajectories.npz'), **traj_archive)

    # ------------------------------------------------------------------
    # Part 3: Requested Cluster Count Sweep m in {2..8} (Table S-II)
    # ------------------------------------------------------------------
    print("\n=== Step 3: Cluster Count Sweep m in {2..8} (Table S-II) ===")
    m_sweep_res = {}
    trk0 = Track('U', scale=2.5, half_width=0.75)
    veh0 = Vehicle(0.05, 2.5, trk0, mu=0.8, delta_max=0.40, acc_max=5.00,
                   sig_vx=0.004, sig_vy=0.004, sig_wz=0.002)
    by0 = 0.9333 * 0.75

    for m_req in range(2, 9):
        tf_m = TubeFMLPCController(xD0, uD0, kapD0, 0.05, 2.5, by0, m_req=m_req)
        _, _, mt_m = tf_m.run_sim(trk0, veh0, T=60.0, x0_offset=x0_off)
        L_m = tf_m.L
        Yr_clean = (Y_clean0 - xref0)[L_m.ok_mask][:, L_m.idx_r]
        errs_m = np.zeros((len(L_m.Xr), 3))
        ema = None; j_prev = -1; dwell = 0
        for k in range(len(L_m.Xr)):
            jk, _, ema, _ = L_m.match_step(L_m.Xr[k], L_m.Utr[k], L_m.kap[k], ema, j_prev, dwell)
            dwell = 1 if (jk != j_prev) else (dwell + 1); j_prev = jk
            pred = L_m.A_list[jk][:3, :] @ L_m.Xr[k] + L_m.B_list[jk][:3, :] @ L_m.Utr[k] + L_m.C_list[jk][:3]
            errs_m[k] = np.abs(pred - Yr_clean[k, :3])
        rms_3d = np.sqrt(np.mean(errs_m ** 2, axis=0))
        dbar_ey_mean = float(np.mean([d[4] for d in L_m.w_bar_list]))
        m_sweep_res[str(m_req)] = {
            'm_act': int(L_m.m),
            'rms_vx': round(float(rms_3d[0]), 5),
            'rms_vy': round(float(rms_3d[1]), 5),
            'rms_wz': round(float(rms_3d[2]), 5),
            'dbar_ey': round(dbar_ey_mean, 4),
            'rmse_ey': mt_m['rmse_ey'],
            'max_ey': mt_m['max_ey'],
            'rmse_epsi': mt_m['rmse_epsi'],
            'viol_pct': mt_m['viol_pct'],
            'time_ms': mt_m['time_ms'],
        }
        print(f"  m_req={m_req} (m_act={L_m.m}): RMSE(ey)={mt_m['rmse_ey']:.4f}, max|ey|={mt_m['max_ey']:.4f}, time={mt_m['time_ms']:.2f}ms")
    all_results['m_sweep'] = m_sweep_res

    # ------------------------------------------------------------------
    # Part 4: Supplementary Studies (Tables S-III to S-VII)
    # ------------------------------------------------------------------
    print("\n=== Step 4: Supplementary Tables S-III to S-VII ===")
    ood_res = {}
    for ood_name, mu_ood, vr_ood, m_mass, Iz_val, bf_mult, sig_mult in [
        ('Unseen Low Friction (mu=0.60, zero-shot)', 0.60, 2.5, 1.98, 0.024, 1.0, 1.0),
        ('Unseen Very-Low Friction (mu=0.50, zero-shot)', 0.50, 2.5, 1.98, 0.024, 1.0, 1.0),
        ('Unseen High Speed (v_xr=3.0 m/s, zero-shot)', 0.80, 3.0, 1.98, 0.024, 1.0, 1.0),
        ('Unseen +50% Payload & -20% Tire Stiffness', 0.80, 2.5, 1.98 * 1.5, 0.024 * 1.8, 0.8, 1.0),
        ('+50% Mass/Inertia Perturbation (D_f,r prop m)', 0.80, 2.5, 1.98 * 1.5, 0.024 * 1.5, 1.0, 1.0),
        ('2x Process Noise Amplification', 0.80, 2.5, 1.98, 0.024, 1.0, 2.0),
    ]:
        veh_ood = Vehicle(
            0.05, vr_ood, trk0, mu=mu_ood, m=m_mass, Iz=Iz_val,
            Bf=bf_mult, Br=bf_mult, delta_max=0.40, acc_max=5.00,
            sig_vx=0.004 * sig_mult, sig_vy=0.004 * sig_mult, sig_wz=0.002 * sig_mult
        )
        tf_ood = TubeFMLPCController(xD0, uD0, kapD0, 0.05, 2.5, by0)
        _, _, mt_ood = tf_ood.run_sim(trk0, veh_ood, T=60.0, x0_offset=x0_off)
        ood_res[ood_name] = mt_ood
        print(f"  [OOD] {ood_name}: RMSE(ey)={mt_ood['rmse_ey']:.4f}, max|ey|={mt_ood['max_ey']:.4f}, joint_cov={mt_ood['joint_cov_pct']}%, viol={mt_ood['viol_pct']:.2f}%")
    all_results['ood_stress'] = ood_res

    # Table S-IV: Feature construction, k-NN sensitivity, and training density
    feat_res = {}
    n_max_0 = len(xD0) - 1
    for cfg_name, f_mode, knn_val, n_sub_data in [
        ('Proposed 6D EMA (knn=15)', '6d_ema', 15, n_max_0),
        ('6D Raw without EMA (alpha_e=0)', '6d_no_ema', 15, n_max_0),
        ('4D State+Curvature Only', '4d_raw', 15, n_max_0),
        ('3D Dynamic States Only', '3d_only', 15, n_max_0),
        ('k-NN Graph Sparsity knn=8', '6d_ema', 8, n_max_0),
        ('k-NN Graph Sparsity knn=25', '6d_ema', 25, n_max_0),
        ('k-NN Graph Sparsity knn=40', '6d_ema', 40, n_max_0),
        ('Training Density N_data=1500 (25%)', '6d_ema', 15, 1500),
        ('Training Density N_data=3000 (50%)', '6d_ema', 15, 3000),
    ]:
        tf_f = TubeFMLPCController(
            xD0[:n_sub_data + 1], uD0[:n_sub_data], kapD0[:n_sub_data + 1],
            0.05, 2.5, by0, m_req=8, feature_mode=f_mode, knn=knn_val,
            use_kappa_gate=(f_mode != '3d_only'), veto_on=(f_mode != '3d_only')
        )
        _, _, mt_f = tf_f.run_sim(trk0, veh0, T=60.0, x0_offset=x0_off)
        L_f = tf_f.L
        Yr_clean_f = (Y_clean0[:n_sub_data] - xref0)[L_f.ok_mask][:, L_f.idx_r]
        errs_c = np.zeros(len(L_f.Xr))
        errs_n = np.zeros(len(L_f.Xr))
        ema = None; j_prev = -1; dwell = 0
        for k in range(len(L_f.Xr)):
            jk, _, ema, _ = L_f.match_step(L_f.Xr[k], L_f.Utr[k], L_f.kap[k], ema, j_prev, dwell)
            dwell = 1 if (jk != j_prev) else (dwell + 1); j_prev = jk
            pred_vx = float(L_f.A_list[jk][0, :] @ L_f.Xr[k] + L_f.B_list[jk][0, :] @ L_f.Utr[k] + L_f.C_list[jk][0])
            errs_c[k] = abs(pred_vx - Yr_clean_f[k, 0])
            errs_n[k] = abs(pred_vx - L_f.Yr[k, 0])
        mt_f['vx_clean_rms_1e3'] = round(float(np.sqrt(np.mean(errs_c ** 2)) * 1e3), 2)
        mt_f['vx_noisy_rms_1e3'] = round(float(np.sqrt(np.mean(errs_n ** 2)) * 1e3), 2)
        feat_res[cfg_name] = mt_f
    all_results['feature_sensitivity'] = feat_res

    # Table S-V: Switching-Veto Ablation, Preview Ablation & Out-of-Envelope Startup Stress
    veto_res = {}
    for v_name, m_r_v, v_on, hyst_v, dwell_v, ey0_v, epsi0_v, use_kg, prev_on in [
        ('Full TubeFM (m=4, Veto + Dwell=5 + Hyst=0.80, Curv.-Gated)', 4, True, 0.80, 5, 0.05, -0.02, True, True),
        ('No Switching-Veto (m=4, Dwell=5 + Hyst=0.80, Curv.-Gated)', 4, False, 0.80, 5, 0.05, -0.02, True, True),
        ('No Horizon Curvature Preview (m=4, C_{i|k}=C^{(c)})', 4, True, 0.80, 5, 0.05, -0.02, True, False),
        ('Full TubeFM (m=8, Veto + Dwell=5 + Hyst=0.80, Curv.-Gated)', 8, True, 0.80, 5, 0.05, -0.02, True, True),
        ('No Switching-Veto (m=8, Dwell=5 + Hyst=0.80, Curv.-Gated)', 8, False, 0.80, 5, 0.05, -0.02, True, True),
        ('Unrestricted Nearest-Cluster (m=8, No Veto, Dwell=1, Hyst=1.0)', 8, False, 1.00, 1, 0.05, -0.02, False, True),
        ('Veto ON without Dwell/Hysteresis (m=8, Dwell=1, Hyst=1.0, Curv.-Gated)', 8, True, 1.00, 1, 0.05, -0.02, True, True),
        ('Large Initial Offset ey(0)=0.35 m', 4, True, 0.80, 5, 0.35, -0.02, True, True),
        ('Large Initial Offset ey(0)=0.45 m', 4, True, 0.80, 5, 0.45, -0.02, True, True),
        ('Extreme Initial Offset ey(0)=0.55 m', 4, True, 0.80, 5, 0.55, -0.02, True, True),
        ('Near-Boundary Offset ey(0)=0.68 m, epsi(0)=+0.09 rad (97% b_y)', 4, True, 0.80, 5, 0.68, 0.09, True, True),
    ]:
        tf_v = TubeFMLPCController(
            xD0, uD0, kapD0, 0.05, 2.5, by0, m_req=m_r_v,
            veto_on=v_on, hyst=hyst_v, min_dwell=dwell_v, use_kappa_gate=use_kg, preview_on=prev_on
        )
        x0_v = np.array([0.0, 0.0, 0.0, epsi0_v, 0.0, ey0_v])
        _, _, mt_v = tf_v.run_sim(trk0, veh0, T=60.0, x0_offset=x0_v)
        veto_res[v_name] = mt_v
    all_results['veto_startup'] = veto_res

    # Table S-VI: Stage-Wise Online Runtime Scaling with m and N
    runtime_res = {}
    for m_r, N_r in [(2, 10), (4, 10), (8, 10), (4, 6), (4, 8), (4, 12), (4, 15)]:
        tf_rt = TubeFMLPCController(xD0, uD0, kapD0, 0.05, 2.5, by0, m_req=m_r, N=N_r)
        _, _, mt_rt = tf_rt.run_sim(trk0, veh0, T=60.0, x0_offset=x0_off)
        runtime_res[f"m={m_r}_N={N_r}"] = {
            'm_act': mt_rt['m_act'],
            't_match_ms': mt_rt['t_match_ms'],
            't_qp_ms': mt_rt['t_qp_ms'],
            't_total_ms': mt_rt['time_ms'],
            't_p95_ms': mt_rt['time_p95_ms'],
            't_p99_ms': mt_rt['time_p99_ms'],
        }
    all_results['runtime_scaling'] = runtime_res

    # Table S-VII: Distance Metric Comparison (Euclidean vs Mahalanobis)
    metric_cmp_res = {}
    for m_req_val, c_label in [(4, 'm=4'), (8, 'm=8')]:
        metric_cmp_res[c_label] = {}
        for m_label, match_m in [
            ('Euclidean Matching (I_d)', 'euclidean'),
            ('Mahalanobis Matching (Sigma_c^{-1})', 'mahalanobis'),
        ]:
            metric_cmp_res[c_label][m_label] = {}
            for scen, dt_s, vr_s, sc_scale, hw_s, mu_s in [
                ('Nominal', 0.05, 2.5, 2.5, 0.75, 0.8),
                ('lam2', 0.05 * np.sqrt(2.0), 2.5 * np.sqrt(2.0), 5.0, 1.50, 0.8),
                ('mu06', 0.05, 2.5, 2.5, 0.75, 0.6),
            ]:
                lam_s = sc_scale / 2.5
                m_veh = 1.98 * (lam_s ** 3)
                lf_veh = 0.125 * lam_s
                lr_veh = 0.125 * lam_s
                Iz_veh = 0.024 * (lam_s ** 5)
                d_arch = scenarios_data[scen]
                trk = Track('U', scale=sc_scale, half_width=hw_s)
                veh = Vehicle(
                    dt_s, vr_s, trk, m=m_veh, lf=lf_veh, lr=lr_veh, Iz=Iz_veh,
                    mu=mu_s, delta_max=0.40, acc_max=5.00,
                    sig_vx=0.004, sig_vy=0.004, sig_wz=0.002
                )
                by_s = 0.9333 * hw_s
                tf_mc = TubeFMLPCController(
                    d_arch['xD'], d_arch['uD'], d_arch['kapD'], dt_s, vr_s, by_s,
                    m_req=m_req_val, match_metric=match_m, use_kappa_gate=False, veto_on=False
                )
                _, _, mt_mc = tf_mc.run_sim(trk, veh, T=60.0, x0_offset=x0_off)
                metric_cmp_res[c_label][m_label][scen] = mt_mc
    all_results['distance_metric_cmp'] = metric_cmp_res

    json_path = os.path.join(DATA_DIR, 'all_python_results.json')
    with open(json_path, 'w') as f:
        json.dump(all_results, f, indent=2)
    export_all_csv_tables(all_results)
    print(f"\nSaved complete verification results, trajectories, and 10 CSV tables to {DATA_DIR}!")
    return all_results


if __name__ == '__main__':
    main()
